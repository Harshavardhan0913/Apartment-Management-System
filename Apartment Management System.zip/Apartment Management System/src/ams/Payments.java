

package ams;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

import com.github.lgooddatepicker.components.DateTimePicker;

import ams.Payments.SwingAction;
import java.awt.event.ActionListener;

public class Payments extends Menu {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Payments frame = new Payments();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace(); 
				}
			}
		});
	}
	
	void clearText() {
		textFieldPaymentsId.setText("");
		textFieldPaymentsAmount.setText("");
		textFieldPaymentsType.setText("");
		comboBoxFlatNo.setSelectedItem(null);
		paymentDate.setDateTimeStrict(null);
		textFieldPaymentsAmount.setText("");
	}

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField textFieldPaymentsId;
	private JTextField textFieldPaymentsType;
	private JTextField textFieldPaymentsAmount;
	private final Action action = new SwingAction();
	private JButton btnAddPaymentsButton;
	private JButton btnUpdatePaymentsButton;
	private JButton btnDeletePaymentsButton;
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	private JLabel lblNewLabel_4;
	JComboBox comboBoxFlatNo;
	DateTimePicker paymentDate;
	private JButton btnClearButton;
	private JButton btnCancelButton;
	public Payments() {
		setTitle("Apartment Management System - Payments");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Payments",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);
		
		
		lblNewLabel = new JLabel("Payment Id");
		lblNewLabel.setBounds(163, 81, 120, 25);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Payment Type");
		lblNewLabel_1.setBounds(163, 110, 120, 25);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Payment Date");
		lblNewLabel_2.setBounds(163, 139, 120, 25);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Payment Amount");
		lblNewLabel_3.setBounds(163, 168, 120, 25);
		contentPane.add(lblNewLabel_3);
		
		textFieldPaymentsId = new JTextField();
		textFieldPaymentsId.setBounds(320, 81, 120, 25);
		contentPane.add(textFieldPaymentsId);
		textFieldPaymentsId.setColumns(10);
		textFieldPaymentsId.setEditable(false);
		
		textFieldPaymentsType = new JTextField();
		textFieldPaymentsType.setBounds(320, 110, 120, 25);
		contentPane.add(textFieldPaymentsType);
		textFieldPaymentsType.setColumns(10);
		
		paymentDate = new DateTimePicker();
		paymentDate.setBounds(320, 139, 250, 25);
        getContentPane().add(paymentDate);
		
		textFieldPaymentsAmount = new JTextField();
		textFieldPaymentsAmount.setBounds(320, 168, 120, 25);
		contentPane.add(textFieldPaymentsAmount);
		textFieldPaymentsAmount.setColumns(10);
		
		lblNewLabel_4 = new JLabel("Flat Number");
		lblNewLabel_4.setBounds(163, 197, 120, 25);
		contentPane.add(lblNewLabel_4);
		
		comboBoxFlatNo = new JComboBox();
		comboBoxFlatNo.setBounds(320, 197, 120, 25);
		contentPane.add(comboBoxFlatNo);
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt = "select flat_no from flats";
			ResultSet rs1 = stmt.executeQuery(txt);
			while(rs1.next()) {
				comboBoxFlatNo.addItem(rs1.getInt(1));
			}
			comboBoxFlatNo.setSelectedItem(null);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		if(login.userType.equals("admin")) {
			
			btnAddPaymentsButton = new JButton("Add");
			btnAddPaymentsButton.setBounds(252, 233, 89, 23);
			contentPane.add(btnAddPaymentsButton);
			btnAddPaymentsButton.addActionListener(action);
			
			btnUpdatePaymentsButton = new JButton("Update");
			btnUpdatePaymentsButton.setBounds(255, 233, 101, 23);
			contentPane.add(btnUpdatePaymentsButton);
			btnUpdatePaymentsButton.addActionListener(action);
			
			btnDeletePaymentsButton = new JButton("Delete");
			btnDeletePaymentsButton.setBounds(377, 233, 114, 23);
			contentPane.add(btnDeletePaymentsButton);
			btnDeletePaymentsButton.addActionListener(action);
			
			btnClearButton = new JButton("Clear");
			btnClearButton.addActionListener(action);
			btnClearButton.setBounds(377, 233, 89, 23);
			contentPane.add(btnClearButton);
			
			btnCancelButton = new JButton("Cancel");
			btnCancelButton.setBounds(138, 233, 89, 23);
			contentPane.add(btnCancelButton);
			btnCancelButton.addActionListener(action);
			
			btnUpdatePaymentsButton.setVisible(false);
			btnDeletePaymentsButton.setVisible(false);
			btnCancelButton.setVisible(false);
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				txt = "select payment_id,payment_amount,payment_date from payments";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Payment Id");
				tableModel.addColumn("Payment Amount");
				tableModel.addColumn("Payment Date");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,286,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddPaymentsButton.setVisible(false);
							btnUpdatePaymentsButton.setVisible(true);
							btnDeletePaymentsButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select payment_id,payment_amount,payment_type,payment_date,flat_no from payments where payment_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldPaymentsId.setText(rs.getString(1));
									textFieldPaymentsAmount.setText(rs.getString(2));
									textFieldPaymentsType.setText(rs.getString(3));
									paymentDate.setDateTimeStrict(rs.getTimestamp(4).toLocalDateTime());
									comboBoxFlatNo.setSelectedItem(rs.getInt(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
			}
			catch(Exception exe) {
				exe.printStackTrace();
			}
		}
		else if(login.userType.equals("user")) {
			textFieldPaymentsId.setEditable(false);
			textFieldPaymentsType.setEditable(false);
			textFieldPaymentsAmount.setEditable(false);
			comboBoxFlatNo.setEditable(false);
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				txt = "select payment_id,payment_amount,payment_date from payments where flat_no ="+login.flatNo+"";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Payment Id");
				tableModel.addColumn("Payment Amount");
				tableModel.addColumn("Payment Date");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,290,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select payment_id,payment_amount,payment_type,payment_date,flat_no from payments where payment_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldPaymentsId.setText(rs.getString(1));
									textFieldPaymentsAmount.setText(rs.getString(2));
									textFieldPaymentsType.setText(rs.getString(3));
									paymentDate.setDateTimeStrict(rs.getTimestamp(4).toLocalDateTime());
									comboBoxFlatNo.setSelectedItem(rs.getString(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
			}
			catch(Exception exe) {
				exe.printStackTrace();
			}
		}
		
	}
	

	public class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddPaymentsButton) {
					
					txt = "insert into payments values('"+textFieldPaymentsId.getText()+"','"+textFieldPaymentsAmount.getText()+"',to_date('"+paymentDate.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),'"+textFieldPaymentsType.getText()+"','"+comboBoxFlatNo.getSelectedItem()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Payment");
					clearText();
					
					 
				}
				else if(e.getSource()==btnDeletePaymentsButton) {
					txt = "delete from payments where payment_id ='"+textFieldPaymentsId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Payment Deleted");
					clearText();
				}
				
				else if(e.getSource()==btnUpdatePaymentsButton) {
					txt = "update payments set payment_id ='"+Integer.parseInt(textFieldPaymentsId.getText())+"',payment_amount='"+Integer.parseInt(textFieldPaymentsAmount.getText())+"',payment_type = '"+textFieldPaymentsType.getText()+"',payment_date = to_date('"+paymentDate.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),flat_no = '"+comboBoxFlatNo.getSelectedItem()+"' where payment_id='"+Integer.parseInt(textFieldPaymentsId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Payment Updated");
					clearText();
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddPaymentsButton.setVisible(true);
					btnUpdatePaymentsButton.setVisible(false);
					btnDeletePaymentsButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText();
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText();
				}
				
				txt = "select payment_id,payment_amount,payment_date from payments";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Payment Id");
				tableModel.addColumn("Payment Amount");
				tableModel.addColumn("Payment Date");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,286,640,150);
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddPaymentsButton.setVisible(false);
							btnUpdatePaymentsButton.setVisible(true);
							btnDeletePaymentsButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select payment_id,payment_amount,payment_type,payment_date,flat_no from payments where payment_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldPaymentsId.setText(rs.getString(1));
									textFieldPaymentsAmount.setText(rs.getString(2));
									textFieldPaymentsType.setText(rs.getString(3));
									paymentDate.setDateTimeStrict(rs.getTimestamp(3).toLocalDateTime());
									comboBoxFlatNo.setSelectedItem(rs.getInt(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}

