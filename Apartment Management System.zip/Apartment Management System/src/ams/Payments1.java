package ams;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

import ams.Payments1.SwingAction;

public class Payments1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Payments1 frame = new Payments1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField textFieldPaymentsId;
	private JTextField textFieldPaymentsType;
	private JTextField textFieldPaymentsDate;
	private JTextField textFieldPaymentsAmount;
	private final Action action = new SwingAction();
	private JMenu mnUsersMenu;
	private JMenu mnAnnouncementsMenu;
	private JMenu mnVisitorsMenu;
	private JMenu mnFlatsMenu;
	private JMenu mnPaymentsMenu;
	private JMenuItem mntmAddPaymentsMenuItem;
	private JMenuItem mntmEditPaymentsMenuItem;
	private JMenuItem mntmDeletePaymentsMenuItem;
	private JButton btnAddPaymentsButton;
	private JButton btnUpdatePaymentsButton;
	private JButton btnDeletePaymentsButton;
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	private JMenu mnChargesMenu;
	private JMenu mnExpensesMenu;
	private JMenu mnNewMenu;
	private JLabel lblNewLabel_4;
	private JTextField textFieldFlatNo;
	public Payments1() {
		setTitle("Apartment Management System - Payments");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 679, 22);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu_3 = new JMenu("Home");
		mnNewMenu_3.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				home h = new home();
				h.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_3);
		
		mnUsersMenu = new JMenu("Users");
		mnUsersMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Users u = new Users();
				u.setVisible(true);
			}
		});
		menuBar.add(mnUsersMenu);
		
		mnAnnouncementsMenu = new JMenu("Announcements");
		mnAnnouncementsMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Announcements a = new Announcements();
				a.setVisible(true);
			}
		});
		
		menuBar.add(mnAnnouncementsMenu);
		
		mnVisitorsMenu = new JMenu("Visitors");
		mnVisitorsMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Visitors v = new Visitors();
				v.setVisible(true);
			}
		});
		
		menuBar.add(mnVisitorsMenu);
		
		mnFlatsMenu = new JMenu("Flats");
		mnFlatsMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Flats f = new Flats();
				f.setVisible(true);
			}
		});
		menuBar.add(mnFlatsMenu);
		
		mnChargesMenu = new JMenu("Charges");
		mnChargesMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Charges c = new Charges();
				c.setVisible(true);
			}
		});
		
		mnExpensesMenu = new JMenu("Expenses");
		menuBar.add(mnExpensesMenu);
		menuBar.add(mnChargesMenu);
		
		mnPaymentsMenu = new JMenu("Payments");
		menuBar.add(mnPaymentsMenu);
		
		mntmAddPaymentsMenuItem = new JMenuItem("Add Payments");
		mnPaymentsMenu.add(mntmAddPaymentsMenuItem);
		mntmAddPaymentsMenuItem.addActionListener(action);
		
		mntmEditPaymentsMenuItem = new JMenuItem("Edit Payments");
		mnPaymentsMenu.add(mntmEditPaymentsMenuItem);
		mntmEditPaymentsMenuItem.addActionListener(action);
		
		mntmDeletePaymentsMenuItem = new JMenuItem("Delete Payments");
		mnPaymentsMenu.add(mntmDeletePaymentsMenuItem);
		mntmDeletePaymentsMenuItem.addActionListener(action);
		
		mnNewMenu = new JMenu("Residents");
		mnNewMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Residents r = new Residents();
				r.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_4 = new JMenu("Committee");
		mnNewMenu_4.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Committee c = new Committee();
				c.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_4);
		
		lblNewLabel = new JLabel("Payment Id");
		lblNewLabel.setBounds(159, 100, 114, 14);
		contentPane.add(lblNewLabel);
		lblNewLabel.setVisible(false);
		
		lblNewLabel_1 = new JLabel("Payment Type");
		lblNewLabel_1.setBounds(159, 125, 114, 14);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setVisible(false);
		
		lblNewLabel_2 = new JLabel("Payment Date");
		lblNewLabel_2.setBounds(159, 150, 114, 14);
		contentPane.add(lblNewLabel_2);
		lblNewLabel_2.setVisible(false);
		
		lblNewLabel_3 = new JLabel("Payment Amount");
		lblNewLabel_3.setBounds(159, 175, 114, 14);
		contentPane.add(lblNewLabel_3);
		lblNewLabel_3.setVisible(false);
		
		textFieldPaymentsId = new JTextField();
		textFieldPaymentsId.setBounds(283, 97, 96, 20);
		contentPane.add(textFieldPaymentsId);
		textFieldPaymentsId.setColumns(10);
		textFieldPaymentsId.setVisible(false);
		
		textFieldPaymentsType = new JTextField();
		textFieldPaymentsType.setBounds(283, 122, 96, 20);
		contentPane.add(textFieldPaymentsType);
		textFieldPaymentsType.setColumns(10);
		textFieldPaymentsType.setVisible(false);
		
		textFieldPaymentsDate = new JTextField();
		textFieldPaymentsDate.setBounds(283, 147, 96, 20);
		contentPane.add(textFieldPaymentsDate);
		textFieldPaymentsDate.setColumns(10);
		textFieldPaymentsDate.setVisible(false);
		
		textFieldPaymentsAmount = new JTextField();
		textFieldPaymentsAmount.setBounds(283, 172, 96, 20);
		contentPane.add(textFieldPaymentsAmount);
		textFieldPaymentsAmount.setColumns(10);
		textFieldPaymentsAmount.setVisible(false);
		
		btnAddPaymentsButton = new JButton("Add");
		btnAddPaymentsButton.setBounds(224, 231, 89, 23);
		contentPane.add(btnAddPaymentsButton);
		btnAddPaymentsButton.setVisible(false);
		btnAddPaymentsButton.addActionListener(action);
		
		btnUpdatePaymentsButton = new JButton("Update");
		btnUpdatePaymentsButton.setBounds(224, 231, 101, 23);
		contentPane.add(btnUpdatePaymentsButton);
		btnUpdatePaymentsButton.setVisible(false);
		btnUpdatePaymentsButton.addActionListener(action);
		
		btnDeletePaymentsButton = new JButton("Delete");
		btnDeletePaymentsButton.setBounds(224, 231, 114, 23);
		contentPane.add(btnDeletePaymentsButton);
		btnDeletePaymentsButton.setVisible(false);
		btnDeletePaymentsButton.addActionListener(action);
		
		lblNewLabel_4 = new JLabel("Flat Number");
		lblNewLabel_4.setBounds(159, 200, 114, 14);
		contentPane.add(lblNewLabel_4);
		lblNewLabel_4.setVisible(false);
		
		textFieldFlatNo = new JTextField();
		textFieldFlatNo.setBounds(283, 200, 96, 20);
		contentPane.add(textFieldFlatNo);
		textFieldFlatNo.setColumns(10);
		textFieldFlatNo.setVisible(false);
	}
	

	public class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==mntmAddPaymentsMenuItem) {
				btnAddPaymentsButton.setVisible(true);
				btnUpdatePaymentsButton.setVisible(false);
				btnDeletePaymentsButton.setVisible(false);
				textFieldPaymentsId.setVisible(true);
				textFieldPaymentsType.setVisible(true);
				textFieldPaymentsDate.setVisible(true);
				textFieldPaymentsAmount.setVisible(true);
				lblNewLabel.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2.setVisible(true);
				lblNewLabel_3.setVisible(true);
				lblNewLabel_4.setVisible(true);
				textFieldFlatNo.setVisible(true);
			}
			else if(e.getSource()==mntmEditPaymentsMenuItem) {
				btnAddPaymentsButton.setVisible(false);
				btnUpdatePaymentsButton.setVisible(true);
				btnDeletePaymentsButton.setVisible(false);
				textFieldPaymentsId.setVisible(true);
				textFieldPaymentsType.setVisible(true);
				textFieldPaymentsDate.setVisible(true);
				textFieldPaymentsAmount.setVisible(true);
				lblNewLabel.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2.setVisible(true);
				lblNewLabel_3.setVisible(true);
				lblNewLabel_4.setVisible(true);
				textFieldFlatNo.setVisible(true);
			}
			else if(e.getSource()==mntmDeletePaymentsMenuItem) {
				btnAddPaymentsButton.setVisible(false);
				btnUpdatePaymentsButton.setVisible(false);
				btnDeletePaymentsButton.setVisible(true);
				textFieldPaymentsId.setVisible(true);
				textFieldPaymentsType.setVisible(true);
				textFieldPaymentsDate.setVisible(true);
				textFieldPaymentsAmount.setVisible(true);
				lblNewLabel.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2.setVisible(true);
				lblNewLabel_3.setVisible(true);
				lblNewLabel_4.setVisible(true);
				textFieldFlatNo.setVisible(true);
			}
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddPaymentsButton) {
					
					txt = "insert into payments values('"+textFieldPaymentsId.getText()+"','"+textFieldPaymentsAmount.getText()+"','"+textFieldPaymentsDate.getText()+"','"+textFieldPaymentsType.getText()+"','"+textFieldFlatNo.getText()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Payment");
					 
				}
				else if(e.getSource()==btnDeletePaymentsButton) {
					txt = "delete from payments where payment_id ='"+textFieldPaymentsId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Payment Deleted");
				}
				
				else if(e.getSource()==btnUpdatePaymentsButton) {
					txt = "update payments set payment_id ='"+Integer.parseInt(textFieldPaymentsId.getText())+"',payment_amount='"+Integer.parseInt(textFieldPaymentsAmount.getText())+"',payment_type = '"+textFieldPaymentsType.getText()+"',payment_date = '"+textFieldPaymentsDate.getText()+"',flat_no = '"+textFieldFlatNo.getText()+"' where payment_id='"+Integer.parseInt(textFieldPaymentsId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Payment Updated");
				}
				
				txt = "select payment_id,payment_amount,payment_date from payments";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Payment Id");
				tableModel.addColumn("Payment Amount");
				tableModel.addColumn("Payment Date");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(0,290,640,400);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select payment_id,payment_amount,payment_type,payment_date,flat_no from payments where payment_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldPaymentsId.setText(rs.getString(1));
									textFieldPaymentsAmount.setText(rs.getString(2));
									textFieldPaymentsType.setText(rs.getString(3));
									textFieldPaymentsDate.setText(new SimpleDateFormat("dd-MMM-yy").format(rs.getDate(4)));
									textFieldFlatNo.setText(rs.getString(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}