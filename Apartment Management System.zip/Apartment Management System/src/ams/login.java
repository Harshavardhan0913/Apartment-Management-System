package ams;

import java.awt.EventQueue;
import ams.*;
import java.sql.*;
import javax.sql.*;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class login {

	private JFrame frmApartmentManagementSystem;
	private JTextField txtLoginId;
	private JPasswordField txtPassword;
	public static String userName;
	public static String loginId;
	public static String userType;
	public static String password;
	public static int flatNo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frmApartmentManagementSystem.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				} 
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		
		frmApartmentManagementSystem = new JFrame();
		frmApartmentManagementSystem.setTitle("Apartment Management System - Log In");
		frmApartmentManagementSystem.setBounds(100, 100, 450, 300);
		frmApartmentManagementSystem.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmApartmentManagementSystem.getContentPane().setLayout(null);
		
		txtLoginId = new JTextField();
		txtLoginId.setBounds(198, 47, 96, 20);
		frmApartmentManagementSystem.getContentPane().add(txtLoginId);
		txtLoginId.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Login Id");
		lblNewLabel.setBounds(76, 50, 84, 14);
		frmApartmentManagementSystem.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(76, 88, 84, 14);
		frmApartmentManagementSystem.getContentPane().add(lblNewLabel_1);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean isValidUser=false;
				try {
					MyDbConnection connect = new MyDbConnection();
					Connection con = connect.getConnection();
					Statement stmt=con.createStatement();
					String txt = "select user_name,login_id,user_type,password from users where login_id = '"+txtLoginId.getText()+"' and password ='"+new String(txtPassword.getPassword())+"'";
					//System.out.println(txt);
					ResultSet rs=stmt.executeQuery(txt);
					if(rs.next()) {
						isValidUser = true;
						userName = rs.getString(1);
						loginId = rs.getString(2);
						userType = rs.getString(3);
						password = rs.getString(4);
					}
					rs.close();
					if(isValidUser) {
						txt = "select flat_no from residents where resident_name in( select user_name from users where user_name ='"+userName+"')";
						ResultSet rs1 = stmt.executeQuery(txt);
						if(rs1.next()) {
							flatNo = rs1.getInt(1);
						}
					}
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				if(isValidUser) {
					frmApartmentManagementSystem.setVisible(false);
					home h = new home();
					h.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(null,"Invalid User");
				}
				
			}
		});
		btnLogin.setBounds(150, 160, 89, 23);
		frmApartmentManagementSystem.getContentPane().add(btnLogin);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(198, 85, 96, 20);
		frmApartmentManagementSystem.getContentPane().add(txtPassword);
	}
}
