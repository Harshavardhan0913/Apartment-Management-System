package ams;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.DateTimePicker;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.Action;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Visitors extends Menu {

	private JPanel contentPane;
	static Visitors frame;
	private JTextField textFieldVisitorId;
	private JTextField textFieldVisitorName;
	private JTextField textFieldNumber;
	private JTextField textFieldFlatId;
	private final Action action = new SwingAction();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try { 
					frame = new Visitors();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JButton btnAddVisitorButton;
	JButton btnUpdateVisitorButton;
	JButton btnDeleteVisitorButton;
	JButton btnClearButton;
	JButton btnCancelButton;
	JLabel lblNewLabel;
	JLabel lblNewLabel_1;
	JLabel lblNewLabel_2;
	JLabel lblNewLabel_3;
	JLabel lblNewLabel_4;
	JLabel lblNewLabel_5;
	JLabel lblNewLabel_6;
	DateTimePicker inDateTime;
	DateTimePicker outDateTime;
	JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	public Visitors() {
		setTitle("Apartment Management System - Visitors");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Visitors",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);
		
		lblNewLabel = new JLabel("Visitor Id");
		lblNewLabel.setBounds(108, 68, 152, 25);
		contentPane.add(lblNewLabel);
		
		
		lblNewLabel_1 = new JLabel("Visitor Name");
		lblNewLabel_1.setBounds(108, 97, 152, 25);
		contentPane.add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("Visitor Number");
		lblNewLabel_2.setBounds(108, 126, 152, 25);
		contentPane.add(lblNewLabel_2);
		
		
		lblNewLabel_3 = new JLabel("Visitor In Date and Time");
		lblNewLabel_3.setBounds(108, 155, 152, 25);
		contentPane.add(lblNewLabel_3);
		
		
		lblNewLabel_4 = new JLabel("Visitor Out Date and Time");
		lblNewLabel_4.setBounds(108, 184, 152, 25);
		contentPane.add(lblNewLabel_4);
		
		
		lblNewLabel_6 = new JLabel("Flat Id");
		lblNewLabel_6.setBounds(108, 213, 152, 25);
		contentPane.add(lblNewLabel_6);
		
		
		textFieldVisitorId = new JTextField();
		textFieldVisitorId.setBounds(270, 68, 161, 25);
		contentPane.add(textFieldVisitorId);
		textFieldVisitorId.setColumns(10);
		textFieldVisitorId.setEditable(false);
		
		
		textFieldVisitorName = new JTextField();
		textFieldVisitorName.setBounds(270, 97, 161, 25);
		contentPane.add(textFieldVisitorName);
		textFieldVisitorName.setColumns(10);
		
		
		textFieldNumber = new JTextField();
		textFieldNumber.addKeyListener(new java.awt.event.KeyAdapter() {
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        if(textFieldNumber.getText().length()>=10&&!(evt.getKeyChar()==KeyEvent.VK_DELETE||evt.getKeyChar()==KeyEvent.VK_BACK_SPACE)||!(evt.getKeyChar()>= '0' &&evt.getKeyChar()<= '9')) {
		            //getToolkit().beep();
		            evt.consume();
		         }
		     }
		});
		
		textFieldNumber.setBounds(270, 126, 161, 25);
		contentPane.add(textFieldNumber);
		textFieldNumber.setColumns(10);
		
		
		inDateTime = new DateTimePicker();
		inDateTime.setBounds(270, 155, 250, 25);
		contentPane.add(inDateTime);
		
		
		
		textFieldFlatId = new JTextField();
		textFieldFlatId.setBounds(270, 213, 161, 25);
		contentPane.add(textFieldFlatId);
		textFieldFlatId.setColumns(10);
		
		
		outDateTime = new DateTimePicker();
		outDateTime.setBounds(270, 184, 250, 25);
		contentPane.add(outDateTime);
		
		
		btnAddVisitorButton = new JButton("Add");
		btnAddVisitorButton.setBounds(249, 266, 89, 23);
		contentPane.add(btnAddVisitorButton);
		btnAddVisitorButton.addActionListener(action);
		btnAddVisitorButton.setVisible(true);
		
		btnUpdateVisitorButton = new JButton("Update");
		btnUpdateVisitorButton.setBounds(249, 266, 105, 23);
		contentPane.add(btnUpdateVisitorButton);
		btnUpdateVisitorButton.addActionListener(action);
		btnUpdateVisitorButton.setVisible(false);
		
		btnDeleteVisitorButton = new JButton("Delete");
		btnDeleteVisitorButton.setBounds(401, 266, 119, 23);
		contentPane.add(btnDeleteVisitorButton);
		btnDeleteVisitorButton.addActionListener(action);
		btnDeleteVisitorButton.setVisible(false);
		
		btnCancelButton = new JButton("Cancel");
		btnCancelButton.setBounds(131, 266, 89, 23);
		contentPane.add(btnCancelButton);
		btnCancelButton.addActionListener(action);
		btnCancelButton.setVisible(false);
		
		btnClearButton = new JButton("Clear");
		btnClearButton.setBounds(375, 266, 103, 23);
		contentPane.add(btnClearButton);
		btnClearButton.addActionListener(action);
		
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt="";
			txt = "select visitor_id,visitor_name,visitor_number,in_date from visitors";
			ResultSet rs = stmt.executeQuery(txt);
			DefaultTableModel tableModel = new DefaultTableModel() ;
			table_1 = new JTable(tableModel);
			tableModel.addColumn("Visitor Id");
			tableModel.addColumn("Visitor Name");
			tableModel.addColumn("Visitor Number");
			int i=0;
			while(rs.next()) {
				tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
				System.out.println(rs.getString(2));
				i++;
			}
			table_1.setVisible(true);
			js.setBounds(20,308,640,150); 	
			getContentPane().add(js);
			js.setViewportView(table_1);
			
			ListSelectionModel model = table_1.getSelectionModel();
			model.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if(!model.isSelectionEmpty()) {
						int selectedRow = model.getMinSelectionIndex();
						btnAddVisitorButton.setVisible(false);
						btnUpdateVisitorButton.setVisible(true);
						btnDeleteVisitorButton.setVisible(true);
						btnCancelButton.setVisible(true);
						btnClearButton.setVisible(false);
						//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
						try {
							String txt = "select visitor_id,visitor_name,visitor_number,in_date,out_date,flat_id from visitors where visitor_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
							ResultSet rs = stmt.executeQuery(txt);
							while(rs.next()) {
								textFieldVisitorId.setText(Integer.toString(rs.getInt(1)));
								textFieldVisitorName.setText(rs.getString(2));
								textFieldNumber.setText(rs.getString(3));
								inDateTime.setDateTimeStrict(rs.getTimestamp(4).toLocalDateTime());
								inDateTime.setDateTimeStrict(rs.getTimestamp(5).toLocalDateTime());
								textFieldFlatId.setText(Integer.toString(rs.getInt(6)));
							}
						}
						catch(Exception exe) {
							exe.printStackTrace();
						}
					}
				}
			});
			
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
	}
	
	void clearText() {
		textFieldVisitorId.setText("");
		textFieldVisitorName.setText("");
		textFieldNumber.setText("");
		inDateTime.setDateTimeStrict(null);
		outDateTime.setDateTimeStrict(null);
		textFieldFlatId.setText("");
	}
	

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddVisitorButton) {
					
					txt = "insert into visitors(visitor_id,visitor_name,visitor_number,in_date,out_date,flat_id) values('"+textFieldVisitorId.getText()+"','"+textFieldVisitorName.getText()+"','"+textFieldNumber.getText()+"',to_date('"+inDateTime.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),to_date('"+outDateTime.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),'"+textFieldFlatId.getText()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Visitor");
					clearText();
					 
				}
				else if(e.getSource()==btnDeleteVisitorButton) {
					txt = "delete from visitors where visitor_id='"+textFieldVisitorId.getText()+"' ";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Visitor Deleted");
					clearText();
				}
				
				else if(e.getSource()==btnUpdateVisitorButton) {
					txt = "update visitors set visitor_id ='"+Integer.parseInt(textFieldVisitorId.getText())+"', visitor_name='"+textFieldVisitorName.getText()+"',visitor_number='"+textFieldNumber.getText()+"',in_date = to_date('"+inDateTime.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),out_date = to_date('"+outDateTime.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),flat_id = '"+Integer.parseInt(textFieldFlatId.getText())+"' where visitor_id='"+textFieldVisitorId.getText()+"' ";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Visitor Updated");
					clearText();
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddVisitorButton.setVisible(true);
					btnUpdateVisitorButton.setVisible(false);
					btnDeleteVisitorButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText();
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText();
				}
				
				txt = "select visitor_id,visitor_name,visitor_number,in_date from visitors";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Visitor Id");
				tableModel.addColumn("Visitor Name");
				tableModel.addColumn("Visitor Number");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,308,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddVisitorButton.setVisible(false);
							btnUpdateVisitorButton.setVisible(true);
							btnDeleteVisitorButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select visitor_id,visitor_name,visitor_number,in_date,out_date,flat_id from visitors where visitor_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldVisitorId.setText(Integer.toString(rs.getInt(1)));
									textFieldVisitorName.setText(rs.getString(2));
									textFieldNumber.setText(rs.getString(3));
									inDateTime.setDateTimeStrict(rs.getTimestamp(4).toLocalDateTime());
									inDateTime.setDateTimeStrict(rs.getTimestamp(5).toLocalDateTime());
									textFieldFlatId.setText(Integer.toString(rs.getInt(6)));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}
