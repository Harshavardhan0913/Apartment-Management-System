package ams;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.event.MenuListener;
import javax.swing.event.MenuEvent;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
 
public class Users extends Menu {

	private JPanel contentPane;
	static Users frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Users();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JMenuItem mntmAddUserMenuItem;
	JMenuItem mntmEditUserMenuItem;
	JMenuItem mntmDeleteUserMenuItem;
	JButton btnAddUserButton;
	JButton btnDeleteUserButton;
	JButton btnUpdateUserButton;
	JButton btnClearButton;
	JButton btnCancelButton;
	JLabel lblNewLabel;
	JLabel lblNewLabel_1;
	JLabel lblNewLabel_2;
	private JTextField textFieldUserName;
	private JTextField textFieldLogInId;
	private JPasswordField textFieldPassword;
	private final Action action = new SwingAction();
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	private JLabel lblNewLabel_3;
	JComboBox comboBoxUserType;
	public Users() {
		setTitle("ApartmentManagement System - Users");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Users",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);
		
		if(true) {
			
			comboBoxUserType = new JComboBox();
			comboBoxUserType.setBounds(320, 173, 152, 25);
			contentPane.add(comboBoxUserType);
			
			lblNewLabel_3 = new JLabel("User Type");
			lblNewLabel_3.setBounds(163, 173, 120, 25);
			contentPane.add(lblNewLabel_3);
			
			btnAddUserButton = new JButton("Submit");
			btnAddUserButton.setBounds(256, 223, 96, 23);
			getContentPane().add(btnAddUserButton);
			btnAddUserButton.addActionListener(action);
			
			btnCancelButton = new JButton("Cancel");
			btnCancelButton.setBounds(157, 223, 89, 23);
			contentPane.add(btnCancelButton);
			btnCancelButton.addActionListener(action);
			btnCancelButton.setVisible(false);
			
			btnDeleteUserButton = new JButton("Delete");
			btnDeleteUserButton.setBounds(404, 223, 120, 23);
			getContentPane().add(btnDeleteUserButton);
			btnDeleteUserButton.addActionListener(action);
			btnDeleteUserButton.setVisible(false);
			
			btnUpdateUserButton = new JButton("Modify");
			btnUpdateUserButton.setBounds(256, 223, 112, 23);
			btnUpdateUserButton.setVisible(false);
			getContentPane().add(btnUpdateUserButton);
			btnUpdateUserButton.addActionListener(action);
			
			btnClearButton = new JButton("Clear");
			btnClearButton.setBounds(394, 223, 103, 23);
			contentPane.add(btnClearButton);
			btnClearButton.addActionListener(action);
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				txt = "select type from UserType";
				ResultSet rs1 = stmt.executeQuery(txt);
				while(rs1.next()) {
					comboBoxUserType.addItem(rs1.getString(1));
				}
				txt = "select user_name,login_id,user_type from users";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("User Name");
				tableModel.addColumn("Login Id");
				tableModel.addColumn("User Type");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,290,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddUserButton.setVisible(false);
							btnUpdateUserButton.setVisible(true);
							btnDeleteUserButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select user_name,login_id,password from users where login_id = '"+table_1.getModel().getValueAt(selectedRow,1)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldUserName.setText(rs.getString(1));
									textFieldLogInId.setText(rs.getString(2));
									textFieldPassword.setText(rs.getString(3));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
			}
			catch(Exception exe) {
				exe.printStackTrace(); 
			}
			
		}
		
		lblNewLabel = new JLabel("UserName");
		lblNewLabel.setBounds(163, 86, 120, 25);
		getContentPane().add(lblNewLabel);
		
		
		lblNewLabel_1 = new JLabel("LogIn Id");
		lblNewLabel_1.setBounds(163, 115, 120, 25);
		getContentPane().add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(163, 144, 120, 25);
		getContentPane().add(lblNewLabel_2);
		
		
		textFieldUserName = new JTextField();
		textFieldUserName.setBounds(320, 86, 152, 25);
		getContentPane().add(textFieldUserName);
		textFieldUserName.setColumns(10);
		
		
		textFieldLogInId = new JTextField();
		textFieldLogInId.setBounds(320, 115, 152, 25);
		getContentPane().add(textFieldLogInId);
		textFieldLogInId.setColumns(10);
		
		
		textFieldPassword = new JPasswordField();
		textFieldPassword.setBounds(320, 144, 152, 25);
		getContentPane().add(textFieldPassword);
		textFieldPassword.setColumns(10);
		
		
		
		
		
		
		if(login.userType.equals("user")) {
			
			textFieldLogInId.setEditable(false);
			
			btnUpdateUserButton = new JButton("Update User");
			btnUpdateUserButton.setBounds(195, 160, 112, 23);
			btnUpdateUserButton.setVisible(true);
			getContentPane().add(btnUpdateUserButton);
			btnUpdateUserButton.addActionListener(action);
			
			textFieldUserName.setText(login.userName);
			textFieldLogInId.setText(login.loginId);
			textFieldPassword.setText(login.password);
			
		}
				
	}

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Add User");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddUserButton) {
					
					txt = "insert into users values('"+textFieldUserName.getText()+"','"+textFieldLogInId.getText()+"','"+textFieldPassword.getText()+"','"+comboBoxUserType.getItemAt(comboBoxUserType.getSelectedIndex())+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added User");
					textFieldUserName.setText("");
					textFieldLogInId.setText("");
					textFieldPassword.setText("");
					 
				}
				
				else if(e.getSource()==btnDeleteUserButton) {
					txt = "delete from users where user_name='"+textFieldUserName.getText()+"' or login_id='"+textFieldLogInId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"User Deleted");
					textFieldUserName.setText("");
					textFieldLogInId.setText("");
					textFieldPassword.setText("");
				}
				
				else if(e.getSource()==btnUpdateUserButton) {
					if(login.userType.equals("user")) {
						txt = "update users set user_name='"+textFieldUserName.getText()+"',login_id='"+textFieldLogInId.getText()+"',password = '"+textFieldPassword.getText()+"' where login_id='"+textFieldLogInId.getText()+"'";
						stmt.executeQuery(txt);
					}
					else if(login.userType.equals("admin")) {
						txt = "update users set user_name='"+textFieldUserName.getText()+"',login_id='"+textFieldLogInId.getText()+"',password = '"+textFieldPassword.getText()+"',user_type = '"+comboBoxUserType.getItemAt(comboBoxUserType.getSelectedIndex())+"' where login_id='"+textFieldLogInId.getText()+"'";
						stmt.executeQuery(txt);
					}
					JOptionPane.showMessageDialog(null,"User Updated");
					textFieldUserName.setText("");
					textFieldLogInId.setText("");
					textFieldPassword.setText("");
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddUserButton.setVisible(true);
					btnUpdateUserButton.setVisible(false);
					btnDeleteUserButton.setVisible(false);
					btnCancelButton.setVisible(false);
					textFieldUserName.setText("");
					textFieldLogInId.setText("");
					textFieldPassword.setText("");
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					textFieldUserName.setText("");
					textFieldLogInId.setText("");
					textFieldPassword.setText("");
				}
				
				if(login.userType.equals("admin")){
					txt = "select user_name,login_id,user_type from users";
				}
				else if(login.userType.equals("user")){
					txt = "select user_name,login_id,user_type from users where login_id = '"+login.loginId+"'";
				}
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("User Name");
				tableModel.addColumn("Login Id");
				tableModel.addColumn("User Type");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,290,640,150);
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							if(login.userType.equals("admin")){
								btnAddUserButton.setVisible(false);
								btnUpdateUserButton.setVisible(true);
								btnDeleteUserButton.setVisible(true);
								btnCancelButton.setVisible(true);
								btnClearButton.setVisible(false);
							}
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select user_name,login_id,password from users where login_id = '"+table_1.getModel().getValueAt(selectedRow,1)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldUserName.setText(rs.getString(1));
									textFieldLogInId.setText(rs.getString(2));
									textFieldPassword.setText(rs.getString(3));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
				JOptionPane.showMessageDialog(null,"Invalid Input. Please try again");
			}
		}
	}
}
