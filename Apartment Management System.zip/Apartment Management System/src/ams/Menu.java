package ams;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

public class Menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JMenuItem mntmAddUserMenuItem;
	JMenuItem mntmEditUserMenuItem;
	JMenuItem mntmDeleteUserMenuItem;
	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		
		JMenu mnUsersMenu = new JMenu("Users");
		mnUsersMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Users u = new Users();
				u.setVisible(true);
			}
		});
		
		JMenu mnNewMenu_3 = new JMenu("Home");
		mnNewMenu_3.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				home h = new home();
				h.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_3);
		menuBar.add(mnUsersMenu);		
		 
				
		if(login.userType.equals("admin")) {
			JMenu mnAnnouncementsMenu = new JMenu("Announcements");
			mnAnnouncementsMenu.addMenuListener(new MenuListener() {
				public void menuCanceled(MenuEvent e) {
				}
				public void menuDeselected(MenuEvent e) {
				}
				public void menuSelected(MenuEvent e) {
					dispose();
					Announcements a = new Announcements();
					a.setVisible(true);
				}
			});
			menuBar.add(mnAnnouncementsMenu);

			JMenu mnVisitorsMenu = new JMenu("Visitors");
			menuBar.add(mnVisitorsMenu);	
			mnVisitorsMenu.addMenuListener(new MenuListener() {
				public void menuCanceled(MenuEvent e) {
				}
				public void menuDeselected(MenuEvent e) {
				}
				public void menuSelected(MenuEvent e) {
					dispose();
					Visitors v = new Visitors();
					v.setVisible(true);
					
				}
			});
			
			JMenu mnFlatsMenu = new JMenu("Flats");
			menuBar.add(mnFlatsMenu);
			
			JMenu mnNewMenu = new JMenu("Expenses");
			mnNewMenu.addMenuListener(new MenuListener() {
				public void menuCanceled(MenuEvent e) {
				}
				public void menuDeselected(MenuEvent e) {
				}
				public void menuSelected(MenuEvent e) {
					dispose();
					Expenses exp = new 	Expenses();
					exp.setVisible(true);
				}
			});
			menuBar.add(mnNewMenu);
			mnFlatsMenu.addMenuListener(new MenuListener() {
				public void menuCanceled(MenuEvent e) {
				}
				public void menuDeselected(MenuEvent e) {
				}
				public void menuSelected(MenuEvent e) {
					dispose();
					Flats f = new Flats();
					f.setVisible(true);
				}
			});
			
			JMenu mnNewMenu1 = new JMenu("Residents");
			mnNewMenu1.addMenuListener(new MenuListener() {
				public void menuCanceled(MenuEvent e) {
				}
				public void menuDeselected(MenuEvent e) {
				}
				public void menuSelected(MenuEvent e) {
					dispose();
					Residents r = new Residents();
					r.setVisible(true);
				}
			});
			menuBar.add(mnNewMenu1);
			
			JMenu mnNewMenu_4 = new JMenu("Committee");
			mnNewMenu_4.addMenuListener(new MenuListener() {
				public void menuCanceled(MenuEvent e) {
				}
				public void menuDeselected(MenuEvent e) {
				}
				public void menuSelected(MenuEvent e) {
					dispose();
					Committee c = new Committee();
					c.setVisible(true);
				}
			});
			menuBar.add(mnNewMenu_4);
			
		}
		
		
		
		JMenu mnNewMenu_1 = new JMenu("Charges");
		mnNewMenu_1.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Charges c = new Charges();
				c.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_1);
		
		JMenu mnNewMenu_2 = new JMenu("Payments");
		mnNewMenu_2.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Payments p = new Payments();
				p.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_2);
		
		

	}

}
