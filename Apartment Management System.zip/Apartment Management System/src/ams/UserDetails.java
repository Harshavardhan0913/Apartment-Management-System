package ams;

public class UserDetails {
	public static String userName;
	public static String loginId;
	public static String userType;
	public static int flatId;
}
