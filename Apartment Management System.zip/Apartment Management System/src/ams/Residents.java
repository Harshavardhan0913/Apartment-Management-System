package ams;
 
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.Action;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class Residents extends Menu {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Residents frame = new Residents();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	JLabel lblNewLabel_1;
	JLabel lblNewLabel_2;
	JLabel lblNewLabel_3;
	JLabel lblNewLabel_4;
	JButton btnClearButton;
	JButton btnCancelButton;
	private JTextField textFieldResidentId;
	private JTextField textFieldResidentName;
	private JTextField textFieldResidentType;
	private JTextField textFieldPhoneNumber;
	private JButton btnAddResidentsButton;
	private JButton btnUpdateResidentsButton;
	private JButton btnDeleteResidentsButton;
	JComboBox comboBoxFlatNo;
	private final Action action = new SwingAction();
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	public Residents() {
		setTitle("Apartment Management System - Residents");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Residents",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);
		
		lblNewLabel = new JLabel("Resident Id");
		lblNewLabel.setBounds(163, 79, 120, 25);
		contentPane.add(lblNewLabel);
		
		
		lblNewLabel_1 = new JLabel("Flat Number");
		lblNewLabel_1.setBounds(163, 195, 120, 25);
		contentPane.add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("Resident Name");
		lblNewLabel_2.setBounds(163, 108, 120, 25);
		contentPane.add(lblNewLabel_2);
		
		
		lblNewLabel_3 = new JLabel("Resident Type");
		lblNewLabel_3.setBounds(163, 166, 120, 25);
		contentPane.add(lblNewLabel_3);
		
		
		lblNewLabel_4 = new JLabel("Phone Number");
		lblNewLabel_4.setBounds(163, 137, 120, 25);
		contentPane.add(lblNewLabel_4);
		
		
		textFieldResidentId = new JTextField();
		textFieldResidentId.setBounds(320, 79, 120, 25);
		contentPane.add(textFieldResidentId);
		textFieldResidentId.setColumns(10);
		textFieldResidentId.setEditable(false);
		
		comboBoxFlatNo = new JComboBox();
		comboBoxFlatNo.setBounds(320, 195, 120, 25);
		contentPane.add(comboBoxFlatNo);
		
		
		textFieldResidentName = new JTextField();
		textFieldResidentName.setBounds(320, 108, 120, 25);
		contentPane.add(textFieldResidentName);
		textFieldResidentName.setColumns(10);
		
		textFieldResidentType = new JTextField();
		textFieldResidentType.setBounds(320, 166, 120, 25);
		contentPane.add(textFieldResidentType);
		textFieldResidentType.setColumns(10);
		
		
		textFieldPhoneNumber = new JTextField();
		textFieldPhoneNumber.setBounds(320, 137, 120, 25);
		contentPane.add(textFieldPhoneNumber);
		textFieldPhoneNumber.setColumns(10);
		textFieldPhoneNumber.addKeyListener(new java.awt.event.KeyAdapter() {
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        if(textFieldPhoneNumber.getText().length()>=10&&!(evt.getKeyChar()==KeyEvent.VK_DELETE||evt.getKeyChar()==KeyEvent.VK_BACK_SPACE)||!(evt.getKeyChar()>= '0' &&evt.getKeyChar()<= '9')) {
		            //getToolkit().beep();
		            evt.consume();
		         }
		     }
		});
		
		
		
		btnAddResidentsButton = new JButton("Submit");
		btnAddResidentsButton.setBounds(224, 260, 89, 23);
		contentPane.add(btnAddResidentsButton);
		btnAddResidentsButton.addActionListener(action);
		
		btnUpdateResidentsButton = new JButton("Modify");
		btnUpdateResidentsButton.setBounds(224, 260, 101, 23);
		contentPane.add(btnUpdateResidentsButton);
		btnUpdateResidentsButton.setVisible(false);
		btnUpdateResidentsButton.addActionListener(action);
		
		btnDeleteResidentsButton = new JButton("Delete");
		btnDeleteResidentsButton.setBounds(350, 260, 114, 23);
		contentPane.add(btnDeleteResidentsButton);
		btnDeleteResidentsButton.setVisible(false);
		btnDeleteResidentsButton.addActionListener(action);
		
		btnCancelButton = new JButton("Cancel");
		btnCancelButton.setBounds(124, 260, 89, 23);
		contentPane.add(btnCancelButton);
		btnCancelButton.addActionListener(action);
		btnCancelButton.setVisible(false);
		
		btnClearButton = new JButton("Clear");
		btnClearButton.setBounds(350, 260, 103, 23);
		contentPane.add(btnClearButton);
		btnClearButton.addActionListener(action);
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt="";
			
			txt = "select flat_no from flats";
			ResultSet rs1 = stmt.executeQuery(txt);
			while(rs1.next()) {
				comboBoxFlatNo.addItem(rs1.getInt(1));
			}
			
			txt = "select resident_id,resident_name,flat_no,phone_number from residents";
			ResultSet rs = stmt.executeQuery(txt);
			DefaultTableModel tableModel = new DefaultTableModel() ;
			table_1 = new JTable(tableModel);
			tableModel.addColumn("Resident Id");
			tableModel.addColumn("Resident Name");
			tableModel.addColumn("Flat Id");
			tableModel.addColumn("Resident Phone Number");
			int i=0;
			while(rs.next()) {
				tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4) });
				System.out.println(rs.getString(2));
				i++;
			}
			table_1.setVisible(true);
			js.setBounds(20,294,640,150);	
			getContentPane().add(js);
			js.setViewportView(table_1);
			
			ListSelectionModel model = table_1.getSelectionModel();
			model.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if(!model.isSelectionEmpty()) {
						int selectedRow = model.getMinSelectionIndex();
						btnAddResidentsButton.setVisible(false);
						btnUpdateResidentsButton.setVisible(true);
						btnDeleteResidentsButton.setVisible(true);
						btnCancelButton.setVisible(true);
						btnClearButton.setVisible(false);
						//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
						try {
							String txt = "select resident_id,flat_no,resident_name,resident_type,phone_number from residents where resident_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
							ResultSet rs = stmt.executeQuery(txt);
							while(rs.next()) {
								textFieldResidentId.setText(rs.getString(1));
								comboBoxFlatNo.setSelectedItem(rs.getInt(2));
								textFieldResidentName.setText(rs.getString(3));
								textFieldResidentType.setText(rs.getString(4));
								textFieldPhoneNumber.setText(rs.getString(5));
							}
						}
						catch(Exception exe) {
							exe.printStackTrace();
						}
					}
				}
			});
			
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
	}
	void clearText() {
		textFieldResidentId.setText("");
		comboBoxFlatNo.setToolTipText("");
		textFieldResidentName.setText("");
		textFieldResidentType.setText("");
		textFieldPhoneNumber.setText("");
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddResidentsButton) {
					
					txt = "insert into residents values('"+textFieldResidentId.getText()+"','"+comboBoxFlatNo.getSelectedItem()+"','"+textFieldResidentName.getText()+"','"+textFieldResidentType.getText()+"','"+textFieldPhoneNumber.getText()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Resident");
					clearText();
					 
				}
				else if(e.getSource()==btnDeleteResidentsButton) {
					txt = "delete from residents where resident_id ='"+textFieldResidentId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Resident Deleted");
					clearText();
				}
				
				else if(e.getSource()==btnUpdateResidentsButton) {
					txt = "update residents set resident_id ='"+Integer.parseInt(textFieldResidentId.getText())+"',flat_no='"+comboBoxFlatNo.getSelectedItem()+"',resident_name = '"+textFieldResidentName.getText()+"',resident_type = '"+textFieldResidentType.getText()+"',phone_number = '"+textFieldPhoneNumber.getText()+"' where resident_id='"+Integer.parseInt(textFieldResidentId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Resident Updated");
					clearText();
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddResidentsButton.setVisible(true);
					btnUpdateResidentsButton.setVisible(false);
					btnDeleteResidentsButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText();
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText();
				}
				
				txt = "select resident_id,resident_name,flat_no,phone_number from residents";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Resident Id");
				tableModel.addColumn("Resident Name");
				tableModel.addColumn("Flat Id");
				tableModel.addColumn("Resident Phone Number");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,294,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddResidentsButton.setVisible(false);
							btnUpdateResidentsButton.setVisible(true);
							btnDeleteResidentsButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select resident_id,flat_no,resident_name,resident_type,phone_number from residents where resident_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldResidentId.setText(rs.getString(1));
									comboBoxFlatNo.setSelectedItem(rs.getInt(2));
									textFieldResidentName.setText(rs.getString(3));
									textFieldResidentType.setText(rs.getString(4));
									textFieldPhoneNumber.setText(rs.getString(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}
