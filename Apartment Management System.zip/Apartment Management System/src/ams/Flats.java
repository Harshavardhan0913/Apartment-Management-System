package ams;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.Action;

public class Flats extends Menu{

	private JPanel contentPane;
	static Flats frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Flats();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	} 

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	JLabel lblNewLabel_1;
	JLabel lblNewLabel_2;
	JLabel lblNewLabel_3;
	private JTextField textFieldFlatId;
	private JTextField textFieldFlatNumber;
	private JTextField textFieldApartmentId;
	private JTextField textFieldFlatType;
	JButton btnClearButton;
	JButton btnCancelButton;
	private JButton btnAddFlatButton;
	private JButton btnUpdateFlatButton;
	private JButton btnDeleteFlatButton;
	private final Action action = new SwingAction();
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	public Flats() {
		setTitle("Apartment Managment System - Flats");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Flats",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);
		
		lblNewLabel = new JLabel("Flat Id");
		lblNewLabel.setBounds(163, 71, 120, 25);
		contentPane.add(lblNewLabel);
		
		
		lblNewLabel_1 = new JLabel("Flat Number");
		lblNewLabel_1.setBounds(163, 100, 120, 25);
		contentPane.add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("Apartment Id");
		lblNewLabel_2.setBounds(163, 129, 120, 25);
		contentPane.add(lblNewLabel_2);
		
		
		lblNewLabel_3 = new JLabel("Flat Type");
		lblNewLabel_3.setBounds(163, 158, 120, 25);
		contentPane.add(lblNewLabel_3);
		
		
		textFieldFlatId = new JTextField();
		textFieldFlatId.setBounds(320, 71, 120, 25);
		contentPane.add(textFieldFlatId);
		textFieldFlatId.setColumns(10);
		textFieldFlatId.setEditable(false);
		
		
		textFieldFlatNumber = new JTextField();
		textFieldFlatNumber.setBounds(320, 100, 120, 25);
		contentPane.add(textFieldFlatNumber);
		textFieldFlatNumber.setColumns(10);
		
		
		textFieldApartmentId = new JTextField();
		textFieldApartmentId.setBounds(320, 129, 120, 25);
		contentPane.add(textFieldApartmentId);
		textFieldApartmentId.setColumns(10);
		
		
		textFieldFlatType = new JTextField();
		textFieldFlatType.setBounds(320, 158, 120, 25);
		contentPane.add(textFieldFlatType);
		textFieldFlatType.setColumns(10);
		
		
		btnAddFlatButton = new JButton("Add");
		btnAddFlatButton.setBounds(237, 235, 89, 23);
		contentPane.add(btnAddFlatButton);
		btnAddFlatButton.setVisible(true);
		btnAddFlatButton.addActionListener(action);
		
		btnUpdateFlatButton = new JButton("Update");
		btnUpdateFlatButton.setBounds(242, 235, 102, 23);
		contentPane.add(btnUpdateFlatButton);
		btnUpdateFlatButton.setVisible(false);
		btnUpdateFlatButton.addActionListener(action);
		
		btnDeleteFlatButton = new JButton("Delete");
		btnDeleteFlatButton.setBounds(368, 235, 115, 23);
		contentPane.add(btnDeleteFlatButton);
		btnDeleteFlatButton.setVisible(false);
		btnDeleteFlatButton.addActionListener(action);
		
		btnCancelButton = new JButton("Cancel");
		btnCancelButton.setBounds(121, 235, 89, 23);
		contentPane.add(btnCancelButton);
		btnCancelButton.addActionListener(action);
		btnCancelButton.setVisible(false);
		
		btnClearButton = new JButton("Clear");
		btnClearButton.setBounds(368, 235, 103, 23);
		contentPane.add(btnClearButton);
		btnClearButton.addActionListener(action);
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt="";
			txt = "select flat_id,flat_no,flat_type from flats";
			ResultSet rs = stmt.executeQuery(txt);
			DefaultTableModel tableModel = new DefaultTableModel() ;
			table_1 = new JTable(tableModel);
			tableModel.addColumn("Flat Id");
			tableModel.addColumn("Flat Number");
			tableModel.addColumn("Flat Type");
			int i=0;
			while(rs.next()) {
				tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
				System.out.println(rs.getString(2));
				i++;
			}
			table_1.setVisible(true);
			js.setBounds(20,290,640,150);	
			getContentPane().add(js);
			js.setViewportView(table_1);
			
			ListSelectionModel model = table_1.getSelectionModel();
			model.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if(!model.isSelectionEmpty()) {
						int selectedRow = model.getMinSelectionIndex();
						btnAddFlatButton.setVisible(false);
						btnUpdateFlatButton.setVisible(true);
						btnDeleteFlatButton.setVisible(true);
						btnCancelButton.setVisible(true);
						btnClearButton.setVisible(false);
						//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
						try {
							String txt = "select flat_id,apartment_id,flat_no,flat_type from flats where flat_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
							ResultSet rs = stmt.executeQuery(txt);
							while(rs.next()) {
								textFieldFlatId.setText(rs.getString(1));
								textFieldApartmentId.setText(rs.getString(2));
								textFieldFlatNumber.setText(rs.getString(3));
								textFieldFlatType.setText(rs.getString(4));
							}
						}
						catch(Exception exe) {
							exe.printStackTrace();
						}
					}
				}
			});
			
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
		
	}
	void clearText() {
		textFieldFlatId.setText("");
		textFieldFlatNumber.setText("");
		textFieldApartmentId.setText("");
		textFieldFlatType.setText("");
	}
	
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddFlatButton) {
					
					txt = "insert into flats values('"+textFieldFlatId.getText()+"','"+textFieldApartmentId.getText()+"','"+textFieldFlatNumber.getText()+"','"+textFieldFlatType.getText()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Flat");
					clearText();
					 
				}
				else if(e.getSource()==btnDeleteFlatButton) {
					txt = "delete from flats where flat_id ='"+textFieldFlatId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Flat Deleted");
					clearText();
				}
				
				else if(e.getSource()==btnUpdateFlatButton) {
					txt = "update flats set flat_id ='"+Integer.parseInt(textFieldFlatId.getText())+"',apartment_id='"+Integer.parseInt(textFieldApartmentId.getText())+"',flat_no = '"+Integer.parseInt(textFieldFlatNumber.getText())+"',flat_type = '"+textFieldFlatType.getText()+"' where flat_id='"+Integer.parseInt(textFieldFlatId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Flat Updated");
					clearText();
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddFlatButton.setVisible(true);
					btnUpdateFlatButton.setVisible(false);
					btnDeleteFlatButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText();
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText();
				}
				
				txt = "select flat_id,flat_no,flat_type from flats";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Flat Id");
				tableModel.addColumn("Flat Number");
				tableModel.addColumn("Flat Type");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,290,640,150);
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddFlatButton.setVisible(false);
							btnUpdateFlatButton.setVisible(true);
							btnDeleteFlatButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select flat_id,apartment_id,flat_no,flat_type from flats where flat_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldFlatId.setText(rs.getString(1));
									textFieldApartmentId.setText(rs.getString(2));
									textFieldFlatNumber.setText(rs.getString(3));
									textFieldFlatType.setText(rs.getString(4));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
				JOptionPane.showMessageDialog(null,"Invalid Input. Please try again");
			}

		}
	}
}
