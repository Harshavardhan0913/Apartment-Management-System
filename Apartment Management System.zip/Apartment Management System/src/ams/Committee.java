package ams;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

import ams.Committee.SwingAction;

public class Committee extends Menu {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Committee frame = new Committee();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	JLabel lblNewLabel_1;
	JLabel lblNewLabel_2;
	JLabel lblNewLabel_3;
	JButton btnClearButton;
	JButton btnCancelButton;
	JComboBox comboBoxFlatNo;
	JComboBox comboBoxMemberType;
	private JTextField textFieldMemberName;
	private JTextField textFieldMemberId;
	private JButton btnAddMemberButton;
	private JButton btnUpdateMemberButton;
	private JButton btnDeleteMemberButton;
	private final Action action = new SwingAction();
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	ArrayList<Integer> array_flats = new ArrayList<Integer>(); 
	public Committee() {
		setTitle("Apartment Managment System - Committee");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Committee",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);

		
		lblNewLabel = new JLabel("Member Id");
		lblNewLabel.setBounds(163, 87, 120, 25);
		contentPane.add(lblNewLabel);
		
		
		
		lblNewLabel_1 = new JLabel("Member Name");
		lblNewLabel_1.setBounds(163, 145, 120, 25); 
		contentPane.add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("Flat Id");
		lblNewLabel_2.setBounds(163, 116, 120, 25);
		contentPane.add(lblNewLabel_2);
		
		
		lblNewLabel_3 = new JLabel("Member Type");
		lblNewLabel_3.setBounds(163, 174, 120, 25);
		contentPane.add(lblNewLabel_3);
		
		comboBoxFlatNo = new JComboBox();
		comboBoxFlatNo.setBounds(320, 116, 120, 25);
		contentPane.add(comboBoxFlatNo);
		comboBoxFlatNo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(comboBoxFlatNo.getSelectedIndex()>0) {
					int s = (Integer) comboBoxFlatNo.getSelectedItem();
					if(array_flats.contains(s)) {
						try {
							//System.out.println(s);
							MyDbConnection connect = new MyDbConnection();
							Connection con = connect.getConnection();
							Statement stmt=con.createStatement();
							String txt="";
							txt = "select resident_name from residents where flat_no='"+s+"'";
							ResultSet rs = stmt.executeQuery(txt);
							if(rs.next()) {
								textFieldMemberName.setText(rs.getString(1));
							}
							
						}
						catch(Exception ex) {
							//System.out.println("not there");
						}
					}
					else {
						textFieldMemberName.setText("");
					}
				}
			}
			
			
		});
		
		
		textFieldMemberName = new JTextField();
		textFieldMemberName.setBounds(320, 145, 120, 25);
		contentPane.add(textFieldMemberName);
		textFieldMemberName.setColumns(10);
		
		comboBoxMemberType = new JComboBox();
		comboBoxMemberType.setBounds(320, 174, 120, 25);
		contentPane.add(comboBoxMemberType);
		
		
		textFieldMemberId = new JTextField();
		textFieldMemberId.setBounds(320, 87, 120, 25);
		contentPane.add(textFieldMemberId);
		textFieldMemberId.setColumns(10);
		textFieldMemberId.setEditable(false);
		
		btnAddMemberButton = new JButton("Submit");
		btnAddMemberButton.setBounds(237, 239, 89, 23);
		contentPane.add(btnAddMemberButton);
		
		btnAddMemberButton.addActionListener(action);
		
		btnUpdateMemberButton = new JButton("Modify");
		btnUpdateMemberButton.setBounds(237, 239, 102, 23);
		contentPane.add(btnUpdateMemberButton);
		btnUpdateMemberButton.setVisible(false);
		btnUpdateMemberButton.addActionListener(action);
		
		btnDeleteMemberButton = new JButton("Delete");
		btnDeleteMemberButton.setBounds(349, 239, 115, 23);
		contentPane.add(btnDeleteMemberButton);
		btnDeleteMemberButton.setVisible(false);
		btnDeleteMemberButton.addActionListener(action);
		
		btnCancelButton = new JButton("Cancel");
		btnCancelButton.setBounds(125, 239, 89, 23);
		contentPane.add(btnCancelButton);
		btnCancelButton.addActionListener(action);
		btnCancelButton.setVisible(false);
		
		btnClearButton = new JButton("Clear");
		btnClearButton.setBounds(351, 239, 103, 23);
		contentPane.add(btnClearButton);
		btnClearButton.addActionListener(action);
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt="";
			
			txt = "select flat_no from flats";
			ResultSet rs1 = stmt.executeQuery(txt);
			while(rs1.next()) {
				comboBoxFlatNo.addItem(rs1.getInt(1));
			}
			rs1.close();
			txt = "select member_type from members";
			ResultSet rs2 = stmt.executeQuery(txt);
			while(rs2.next()) {
				comboBoxMemberType.addItem(rs2.getString(1));
			}
			rs2.close();
			
			txt = "select flat_no from residents";
			ResultSet rs3 = stmt.executeQuery(txt);
			while(rs3.next()) {
				array_flats.add(rs3.getInt(1));
			}
			rs3.close();
			
			txt = "select member_id,member_name,member_type from committee";
			ResultSet rs = stmt.executeQuery(txt);
			DefaultTableModel tableModel = new DefaultTableModel() ;
			table_1 = new JTable(tableModel);
			tableModel.addColumn("Member Id");
			tableModel.addColumn("Member Name");
			tableModel.addColumn("Member Type");
			int i=0;
			while(rs.next()) {
				tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
				System.out.println(rs.getString(2));
				i++;
			}
			table_1.setVisible(true);
			js.setBounds(20,290,640,150);
			getContentPane().add(js);
			js.setViewportView(table_1);
			
			ListSelectionModel model = table_1.getSelectionModel();
			model.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if(!model.isSelectionEmpty()) {
						int selectedRow = model.getMinSelectionIndex();
						btnAddMemberButton.setVisible(false);
						btnUpdateMemberButton.setVisible(true);
						btnDeleteMemberButton.setVisible(true);
						btnCancelButton.setVisible(true);
						btnClearButton.setVisible(false);
						//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
						try {
							String txt = "select member_id,member_name,flat_no,member_type from committee where member_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
							ResultSet rs = stmt.executeQuery(txt);
							while(rs.next()) {
								textFieldMemberId.setText(rs.getString(1));
								textFieldMemberName.setText(rs.getString(2));
								comboBoxFlatNo.setSelectedItem(rs.getInt(3));
								comboBoxMemberType.setSelectedItem(rs.getString(4));
							}
						}
						catch(Exception exe) {
							exe.printStackTrace();
						}
					}
				}
			});
			
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
				
	}
	void clearText() {
		textFieldMemberId.setText("");
		comboBoxFlatNo.setSelectedItem(null);
		textFieldMemberName.setText("");
		comboBoxMemberType.setSelectedIndex(-1);
	}
	public class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddMemberButton) {
					
					txt = "insert into committee values('"+textFieldMemberId.getText()+"','"+textFieldMemberName.getText()+"','"+comboBoxFlatNo.getSelectedItem()+"','"+comboBoxMemberType.getSelectedItem()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Member");
					clearText();
					 
				}
				else if(e.getSource()==btnDeleteMemberButton) {
					txt = "delete from committee where member_id ='"+textFieldMemberId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Member Deleted");
					clearText();
				}
				
				else if(e.getSource()==btnUpdateMemberButton) {
					txt = "update committee set member_id ='"+Integer.parseInt(textFieldMemberId.getText())+"',flat_no='"+comboBoxFlatNo.getSelectedItem()+"',member_name = '"+textFieldMemberName.getText()+"',member_type = '"+comboBoxMemberType.getSelectedItem()+"' where member_id='"+Integer.parseInt(textFieldMemberId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Member Updated");
					clearText();
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddMemberButton.setVisible(true);
					btnUpdateMemberButton.setVisible(false);
					btnDeleteMemberButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText();
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText();
				}
				
				txt = "select member_id,member_name,member_type from committee";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Member Id");
				tableModel.addColumn("Member Name");
				tableModel.addColumn("Member Type");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,290,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddMemberButton.setVisible(false);
							btnUpdateMemberButton.setVisible(true);
							btnDeleteMemberButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select member_id,member_name,flat_no,member_type from committee where member_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldMemberId.setText(rs.getString(1));
									textFieldMemberName.setText(rs.getString(2));
									comboBoxFlatNo.setSelectedItem(rs.getInt(3));
									comboBoxMemberType.setSelectedItem(rs.getString(4));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
				ex.printStackTrace();
			}

		}
	}
}
