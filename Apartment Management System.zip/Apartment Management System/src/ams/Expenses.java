package ams;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JMenuBar;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JMenu;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.Action;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.event.MenuListener;
import javax.swing.event.MenuEvent;

public class Expenses extends Menu {

	private JPanel contentPane;
 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Expenses frame = new Expenses();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}  
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField textFieldExpenseId;
	private JTextField textFieldExpenseType;
	private JTextField textFieldExpenseDescription;
	private JTextField textFieldExpenseAmount;
	JButton btnClearButton;
	JButton btnCancelButton;
	private final Action action = new SwingAction();
	private JButton btnAddExpensesButton;
	private JButton btnUpdateExpensesButton;
	private JButton btnDeleteExpensesButton;
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	public Expenses() {
		setTitle("Apartment Management System - Expenses");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
				
		JLabel lblNewLabel = new JLabel("Apartment Management System - Expenses",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);
		
		lblNewLabel = new JLabel("Expense Id");
		lblNewLabel.setBounds(163, 75, 120, 25);
		contentPane.add(lblNewLabel);
		
		
		lblNewLabel_1 = new JLabel("Expense Type");
		lblNewLabel_1.setBounds(163, 104, 120, 25);
		contentPane.add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("Expense description");
		lblNewLabel_2.setBounds(163, 133, 120, 25);
		contentPane.add(lblNewLabel_2);
		
		
		lblNewLabel_3 = new JLabel("Expense Amount");
		lblNewLabel_3.setBounds(163, 162, 120, 25);
		contentPane.add(lblNewLabel_3);
		
		
		textFieldExpenseId = new JTextField();
		textFieldExpenseId.setBounds(320, 75, 152, 25);
		contentPane.add(textFieldExpenseId);
		textFieldExpenseId.setColumns(10);
		textFieldExpenseId.setEditable(false);
		
		textFieldExpenseType = new JTextField();
		textFieldExpenseType.setBounds(320, 104, 152, 25);
		contentPane.add(textFieldExpenseType);
		textFieldExpenseType.setColumns(10);
		
		
		textFieldExpenseDescription = new JTextField();
		textFieldExpenseDescription.setBounds(320, 133, 152, 25);
		contentPane.add(textFieldExpenseDescription);
		textFieldExpenseDescription.setColumns(10);
		
		
		textFieldExpenseAmount = new JTextField();
		textFieldExpenseAmount.setBounds(320, 162, 152, 25);
		contentPane.add(textFieldExpenseAmount);
		textFieldExpenseAmount.setColumns(10);
		
		
		btnAddExpensesButton = new JButton("Submit");
		btnAddExpensesButton.setBounds(236, 209, 89, 23);
		contentPane.add(btnAddExpensesButton);
		btnAddExpensesButton.addActionListener(action);
		
		btnUpdateExpensesButton = new JButton("Modify");
		btnUpdateExpensesButton.setBounds(236, 209, 101, 23);
		contentPane.add(btnUpdateExpensesButton);
		btnUpdateExpensesButton.setVisible(false);
		btnUpdateExpensesButton.addActionListener(action);
		
		btnDeleteExpensesButton = new JButton("Delete");
		btnDeleteExpensesButton.setBounds(382, 209, 114, 23);
		contentPane.add(btnDeleteExpensesButton);
		btnDeleteExpensesButton.setVisible(false);
		btnDeleteExpensesButton.addActionListener(action);
		
		btnCancelButton = new JButton("Cancel");
		btnCancelButton.setBounds(126, 209, 89, 23);
		contentPane.add(btnCancelButton);
		btnCancelButton.addActionListener(action);
		btnCancelButton.setVisible(false);
		
		btnClearButton = new JButton("Clear");
		btnClearButton.setBounds(370, 209, 103, 23);
		contentPane.add(btnClearButton);
		btnClearButton.addActionListener(action);
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt="";
			txt = "select expense_id,expense_desc,expense_amount from expenses";
			ResultSet rs = stmt.executeQuery(txt);
			DefaultTableModel tableModel = new DefaultTableModel() ;
			table_1 = new JTable(tableModel);
			tableModel.addColumn("Expenses Id");
			tableModel.addColumn("Expenses Description");
			tableModel.addColumn("Expenses Amount");
			int i=0;
			while(rs.next()) {
				tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
				System.out.println(rs.getString(2));
				i++;
			}
			table_1.setVisible(true);
			js.setBounds(20,250,640,196);	
			getContentPane().add(js);
			js.setViewportView(table_1);
			
			ListSelectionModel model = table_1.getSelectionModel();
			model.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if(!model.isSelectionEmpty()) {
						int selectedRow = model.getMinSelectionIndex();
						btnAddExpensesButton.setVisible(false);
						btnUpdateExpensesButton.setVisible(true);
						btnDeleteExpensesButton.setVisible(true);
						btnCancelButton.setVisible(true);
						btnClearButton.setVisible(false);
						//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
						try {
							String txt = "select expense_id,expense_amount,expense_type,expense_desc from expenses where expense_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
							ResultSet rs = stmt.executeQuery(txt);
							while(rs.next()) {
								textFieldExpenseId.setText(rs.getString(1));
								textFieldExpenseAmount.setText(rs.getString(2));
								textFieldExpenseType.setText(rs.getString(3));
								textFieldExpenseDescription.setText(rs.getString(4));
							}
						}
						catch(Exception exe) {
							exe.printStackTrace();
						}
					}
				}
			});
			
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
	}
	
	void clearText() {
		textFieldExpenseId.setText("");
		textFieldExpenseAmount.setText("");
		textFieldExpenseType.setText("");
		textFieldExpenseDescription.setText("");
	}

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddExpensesButton) {
					
					txt = "insert into expenses values('"+textFieldExpenseId.getText()+"','"+textFieldExpenseType.getText()+"','"+textFieldExpenseDescription.getText()+"','"+textFieldExpenseAmount.getText()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Expense");
					clearText();
					 
				}
				else if(e.getSource()==btnDeleteExpensesButton) {
					txt = "delete from expenses where expense_id ='"+textFieldExpenseId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Expense Deleted");
					clearText();
				}
				
				else if(e.getSource()==btnUpdateExpensesButton) {
					txt = "update expenses set expense_id ='"+Integer.parseInt(textFieldExpenseId.getText())+"',expense_amount='"+Integer.parseInt(textFieldExpenseAmount.getText())+"',expense_type = '"+textFieldExpenseType.getText()+"',expense_desc = '"+textFieldExpenseDescription.getText()+"' where expense_id='"+Integer.parseInt(textFieldExpenseId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Expense Updated");
					clearText();
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddExpensesButton.setVisible(true);
					btnUpdateExpensesButton.setVisible(false);
					btnDeleteExpensesButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText();
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText();
				}
				
				txt = "select expense_id,expense_desc,expense_amount from expenses";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Expenses Id");
				tableModel.addColumn("Expenses Description");
				tableModel.addColumn("Expenses Amount");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,250,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddExpensesButton.setVisible(false);
							btnUpdateExpensesButton.setVisible(true);
							btnDeleteExpensesButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select expense_id,expense_amount,expense_type,expense_desc from expenses where expense_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldExpenseId.setText(rs.getString(1));
									textFieldExpenseAmount.setText(rs.getString(2));
									textFieldExpenseType.setText(rs.getString(3));
									textFieldExpenseDescription.setText(rs.getString(4));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}
