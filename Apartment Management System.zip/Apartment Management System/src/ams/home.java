
package ams;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.Action;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.event.MenuListener;
import javax.swing.event.MenuEvent;
import java.awt.Font;
import java.awt.Color;

public class home extends Menu {
	private final Action action = new SwingAction();
	static home frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} 
		});
	}

	/**
	 * Create the frame.
	 */

	public home() {
		setTitle("Apartment Management System - Home");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		
		
		try {
			DefaultListModel<String> l1 = new DefaultListModel<>(); 
			l1.addElement("          Welcome "+login.userName+" ");
			l1.addElement("				");
			l1.addElement("				");
	        MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement(); 
			String txt="select announcement_desc from announcements where sysdate between ANNOUNCEMENT_START_DATE and ANNOUNCEMENT_END_DATE";
			ResultSet rs = stmt.executeQuery(txt);
			while(rs.next()) {
				l1.addElement(" - "+rs.getString(1));
				System.out.println(" - "+rs.getString(1));
			}
	        getContentPane().setLayout(null);
	        
	        JLabel lblNewLabel = new JLabel("Apartment Management System - Home",SwingConstants.CENTER);
			lblNewLabel.setForeground(Color.BLACK);
	        lblNewLabel.setBackground(new Color(227, 227, 227)); 
	        lblNewLabel.setOpaque(true);
	        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
	        lblNewLabel.setBounds(0, 0, 679, 60);
	        getContentPane().add(lblNewLabel);
	        
	        JLabel lblNewLabel_1 = new JLabel("Announcements");
	        lblNewLabel_1.setBackground(Color.WHITE);
	        lblNewLabel_1.setForeground(Color.RED);
	        lblNewLabel_1.setFont(new Font("Lucida Handwriting", Font.ITALIC, 16));
	        lblNewLabel_1.setBounds(10, 86, 168, 27);
	        getContentPane().add(lblNewLabel_1);
	        JList<String> list = new JList<>(l1);  
	        list.setVisible(true);
	        list.setBounds(0,60,679,524);
	        getContentPane().add(list);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	public void actionPerformed(ActionEvent e) {
		
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
		}
	}
}
