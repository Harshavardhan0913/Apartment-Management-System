

package ams;
 
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

import ams.Charges.SwingAction;
import javax.swing.JComboBox;

public class Charges extends Menu {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Charges frame = new Charges();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField textFieldChargesId;
	private JTextField textFieldChargesType;
	private JTextField textFieldChargesDescription;
	private JTextField textFieldChargesAmount;
	private final Action action = new SwingAction();
	private JButton btnAddChargesButton;
	private JButton btnUpdateChargesButton;
	private JButton btnDeleteChargesButton;
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	private JLabel lblNewLabel_4;
	JButton btnViewChargesButton;
	private JButton btnPayChargeButton;
	private JButton btnCancelButton;
	private JButton btnClearButton;
	JComboBox comboBoxFlatNo;
	public Charges() {
		setTitle("Apartment Management System - Charges");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Charges",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);

		
		lblNewLabel = new JLabel("Charge Id");
		lblNewLabel.setBounds(163, 63, 120, 25);
		contentPane.add(lblNewLabel);
		
		
		lblNewLabel_1 = new JLabel("Charge Type");
		lblNewLabel_1.setBounds(163, 92, 120, 25);
		contentPane.add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("Charge description");
		lblNewLabel_2.setBounds(163, 121, 120, 25);
		contentPane.add(lblNewLabel_2);
		
		
		lblNewLabel_3 = new JLabel("Charge Amount");
		lblNewLabel_3.setBounds(163, 150, 120, 25);
		contentPane.add(lblNewLabel_3);
		
		
		textFieldChargesId = new JTextField();
		textFieldChargesId.setBounds(320, 63, 152, 25);
		contentPane.add(textFieldChargesId);
		textFieldChargesId.setColumns(10);
		textFieldChargesId.setEditable(false);	
		
		
		textFieldChargesType = new JTextField();
		textFieldChargesType.setBounds(320, 92, 152, 25);
		contentPane.add(textFieldChargesType);
		textFieldChargesType.setColumns(10);
		
		
		textFieldChargesDescription = new JTextField();
		textFieldChargesDescription.setBounds(320, 121, 152, 25);
		contentPane.add(textFieldChargesDescription);
		textFieldChargesDescription.setColumns(10);
		
		
		textFieldChargesAmount = new JTextField();
		textFieldChargesAmount.setBounds(320, 150, 152, 25);
		contentPane.add(textFieldChargesAmount);
		textFieldChargesAmount.setColumns(10);
		
		
		lblNewLabel_4 = new JLabel("Flat Number");
		lblNewLabel_4.setBounds(163, 179, 120, 25);
		contentPane.add(lblNewLabel_4);
		lblNewLabel_4.setVisible(false);
		
		comboBoxFlatNo = new JComboBox();
		comboBoxFlatNo.setBounds(320, 179, 152, 25);
		contentPane.add(comboBoxFlatNo);
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt = "select flat_no from flats";
			ResultSet rs1 = stmt.executeQuery(txt);
			while(rs1.next()) {
				comboBoxFlatNo.addItem(rs1.getInt(1));
			}
			comboBoxFlatNo.setSelectedItem(null);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		if(login.userType.equals("user")) {
			btnViewChargesButton = new JButton("View Charges");
			btnViewChargesButton.setBounds(10, 64, 133, 23);
			contentPane.add(btnViewChargesButton);
			btnViewChargesButton.addActionListener(action);
			lblNewLabel.setVisible(false);
			lblNewLabel_1.setVisible(false);
			lblNewLabel_2.setVisible(false);
			lblNewLabel_3.setVisible(false);
			textFieldChargesId.setVisible(false);
			textFieldChargesType.setVisible(false);
			textFieldChargesDescription.setVisible(false);
			textFieldChargesAmount.setVisible(false);
			comboBoxFlatNo.setVisible(false);
			textFieldChargesType.setEditable(false);
			textFieldChargesDescription.setEditable(false);
			textFieldChargesAmount.setEditable(false);
			comboBoxFlatNo.setEditable(false);
			
			btnPayChargeButton = new JButton("Pay");
			btnPayChargeButton.setBounds(228, 244, 89, 23);
			contentPane.add(btnPayChargeButton);
			btnPayChargeButton.addActionListener(action);
			btnPayChargeButton.setVisible(false);
		}
		
		if(login.userType.equals("admin")) {
			textFieldChargesId.setVisible(true);
			textFieldChargesType.setVisible(true);
			textFieldChargesDescription.setVisible(true);
			textFieldChargesAmount.setVisible(true);
			comboBoxFlatNo.setVisible(true);
			lblNewLabel.setVisible(true);
			lblNewLabel_1.setVisible(true);
			lblNewLabel_2.setVisible(true);
			lblNewLabel_3.setVisible(true);
			lblNewLabel_4.setVisible(true);
			
			btnAddChargesButton = new JButton("Submit");
			btnAddChargesButton.setBounds(224, 221, 89, 23);
			contentPane.add(btnAddChargesButton);
			btnAddChargesButton.addActionListener(action);
			
			btnCancelButton = new JButton("Cancel");
			btnCancelButton.setBounds(81, 221, 89, 23);
			contentPane.add(btnCancelButton);
			btnCancelButton.addActionListener(action);
			btnCancelButton.setVisible(false);
			
			btnUpdateChargesButton = new JButton("Modify");
			btnUpdateChargesButton.setBounds(224, 221, 89, 23);
			contentPane.add(btnUpdateChargesButton);
			btnUpdateChargesButton.addActionListener(action);
			btnUpdateChargesButton.setVisible(false);
			
			btnDeleteChargesButton = new JButton("Delete");
			btnDeleteChargesButton.setBounds(359, 221, 101, 23);
			contentPane.add(btnDeleteChargesButton);
			btnDeleteChargesButton.addActionListener(action);
			btnDeleteChargesButton.setVisible(false);
			
			btnClearButton = new JButton("Clear");
			btnClearButton.setBounds(359, 221, 122, 23);
			contentPane.add(btnClearButton);
			btnClearButton.addActionListener(action);
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt;
				txt = "select charges_id,charges_type,charges_amount,flat_no from charges where status='unpaid'";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("charges Id");
				tableModel.addColumn("charges Type");
				tableModel.addColumn("charges Amount");
				tableModel.addColumn("Flat Number");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,250,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							if(login.userType.equals("admin")) {
								btnAddChargesButton.setVisible(false);
								btnUpdateChargesButton.setVisible(true);
								btnDeleteChargesButton.setVisible(true);
								btnCancelButton.setVisible(true);
								btnClearButton.setVisible(false);
							}
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select charges_id,charges_amount,charges_type,charges_desc,flat_no from charges where charges_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldChargesId.setText(rs.getString(1));
									textFieldChargesAmount.setText(rs.getString(2));
									textFieldChargesType.setText(rs.getString(3));
									textFieldChargesDescription.setText(rs.getString(4));
									comboBoxFlatNo.setSelectedItem(rs.getInt(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
			}
			catch(Exception e){
				
			}
		}
		
		
		
	}
	
	void clearText() {
		textFieldChargesId.setText("");
		textFieldChargesAmount.setText("");
		textFieldChargesType.setText("");
		textFieldChargesDescription.setText("");
		comboBoxFlatNo.setToolTipText("");
	}

	public class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				if(e.getSource()==btnViewChargesButton) {
					btnViewChargesButton.setVisible(false);
					textFieldChargesId.setVisible(true);
					textFieldChargesType.setVisible(true);
					textFieldChargesDescription.setVisible(true);
					textFieldChargesAmount.setVisible(true);
					comboBoxFlatNo.setVisible(true);
					lblNewLabel.setVisible(true);
					lblNewLabel_1.setVisible(true);
					lblNewLabel_2.setVisible(true);
					lblNewLabel_3.setVisible(true);
					lblNewLabel_4.setVisible(true);
					btnPayChargeButton.setVisible(true);
				}
				else if(e.getSource()==btnPayChargeButton) {
					try {
						txt = "insert into payments (payment_amount,payment_date,payment_type,flat_no,charge_id) values("+Integer.parseInt(textFieldChargesAmount.getText())+",sysdate,'card','"+comboBoxFlatNo.getSelectedItem()+"','"+textFieldChargesId.getText()+"')";
						stmt.executeQuery(txt);
						//txt = "delete from charges where charges_id ='"+textFieldChargesId.getText()+"'";
						txt = "update charges set status='paid' where charges_id = "+textFieldChargesId.getText()+"";
						stmt.executeQuery(txt);
						JOptionPane.showMessageDialog(null,"Charge Paid");
					}
					catch(Exception ex) {
						JOptionPane.showMessageDialog(null,"Invalid");
					}
				}
				else if(e.getSource()==btnAddChargesButton) {
					
					txt = "insert into charges(charges_id,flat_no,charges_type,charges_desc,charges_amount) values('"+textFieldChargesId.getText()+"','"+comboBoxFlatNo.getSelectedItem()+"','"+textFieldChargesType.getText()+"','"+textFieldChargesDescription.getText()+"','"+textFieldChargesAmount.getText()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Charges");
					clearText();
					 
				}
				else if(e.getSource()==btnDeleteChargesButton) {
					txt = "delete from charges where charges_id ='"+textFieldChargesId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Charges Deleted");
					clearText();
				}
				
				else if(e.getSource()==btnUpdateChargesButton) {
					txt = "update charges set charges_id ='"+Integer.parseInt(textFieldChargesId.getText())+"',flat_no = '"+comboBoxFlatNo.getSelectedItem()+"',charges_amount='"+Integer.parseInt(textFieldChargesAmount.getText())+"',charges_type = '"+textFieldChargesType.getText()+"',charges_desc = '"+textFieldChargesDescription.getText()+"' where charges_id='"+Integer.parseInt(textFieldChargesId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Charges Updated");
					clearText();
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddChargesButton.setVisible(true);
					btnUpdateChargesButton.setVisible(false);
					btnDeleteChargesButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText();
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText();
				}
				if(login.userType.equals("user")){
					txt = "select charges_id,charges_type,charges_amount,flat_no from charges where flat_no = "+login.flatNo+" and status='unpaid'";
				}
				else {
					txt = "select charges_id,charges_type,charges_amount,flat_no from charges where status='unpaid'";
				}
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("charges Id");
				tableModel.addColumn("charges Type");
				tableModel.addColumn("charges Amount");
				tableModel.addColumn("Flat Number");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,250,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							if(login.userType.equals("admin")) {
								btnAddChargesButton.setVisible(false);
								btnUpdateChargesButton.setVisible(true);
								btnDeleteChargesButton.setVisible(true);
								btnCancelButton.setVisible(true);
								btnClearButton.setVisible(false);
							}
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select charges_id,charges_amount,charges_type,charges_desc,flat_no from charges where charges_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldChargesId.setText(rs.getString(1));
									textFieldChargesAmount.setText(rs.getString(2));
									textFieldChargesType.setText(rs.getString(3));
									textFieldChargesDescription.setText(rs.getString(4));
									comboBoxFlatNo.setSelectedItem(rs.getInt(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}

