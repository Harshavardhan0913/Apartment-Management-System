package ams;

import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.Date;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.DateTimePicker;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.UIManager;

public class Announcements extends Menu {

	private JPanel contentPane;
	private final Action action = new SwingAction();
	static Announcements frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Announcements();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	private JTextField textFieldAnnouncementDescription;
	JLabel lblNewLabel;
	JLabel lblNewLabel_1;
	JLabel lblNewLabel_2;
	JButton btnAddAnnouncementButton;
	JButton btnUpdateAnnouncementButton;
	JButton btnDeleteAnnouncementButton;
	JButton btnCancelButton;
	JButton btnClearButton;
	DateTimePicker startDate;
	DateTimePicker endDate;
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	private JLabel lblNewLabel_3;
	private JTextField textFieldAnnouncementId;
	
	
	public Announcements() {
		setTitle("ApartmentManagement System - Announcements");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Apartment Management System - Announcements",SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setBackground(new Color(227, 227, 227)); 
        lblNewLabel.setOpaque(true);
        lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
        lblNewLabel.setBounds(0, 0, 679, 60);
        getContentPane().add(lblNewLabel);
		
		lblNewLabel_3 = new JLabel("Announcement Id");
		lblNewLabel_3.setBounds(132, 67, 178, 25);
		contentPane.add(lblNewLabel_3);
		
		lblNewLabel = new JLabel("Announcement Description");
		lblNewLabel.setBounds(132, 96, 178, 25);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Start Date");
		lblNewLabel_1.setBounds(132, 125, 178, 25);
		contentPane.add(lblNewLabel_1);
		
		
		lblNewLabel_2 = new JLabel("End Date");
		lblNewLabel_2.setBounds(132, 154, 178, 25);
		contentPane.add(lblNewLabel_2);
		
		textFieldAnnouncementId = new JTextField();
		textFieldAnnouncementId.setBounds(320, 67, 152, 25);
		contentPane.add(textFieldAnnouncementId);
		textFieldAnnouncementId.setColumns(10);
		textFieldAnnouncementId.setEditable(false);
		
		textFieldAnnouncementDescription = new JTextField();
		textFieldAnnouncementDescription.setBounds(320, 96, 250, 25);
		contentPane.add(textFieldAnnouncementDescription);
		textFieldAnnouncementDescription.setColumns(10);
		
		startDate = new DateTimePicker();
		startDate.setBounds(320, 125, 250, 25);
        getContentPane().add(startDate);
		
        endDate = new DateTimePicker();
        endDate.setBounds(320, 154, 250, 25);
        getContentPane().add(endDate);
		
		
		btnAddAnnouncementButton = new JButton("Add");
		btnAddAnnouncementButton.setBounds(254, 207, 89, 23);
		contentPane.add(btnAddAnnouncementButton);
		btnAddAnnouncementButton.setVisible(true);
		btnAddAnnouncementButton.addActionListener(action);
		
		btnUpdateAnnouncementButton = new JButton("Update");
		btnUpdateAnnouncementButton.setBounds(254, 207, 96, 23);
		contentPane.add(btnUpdateAnnouncementButton);
		btnUpdateAnnouncementButton.addActionListener(action);
		btnUpdateAnnouncementButton.setVisible(false);
		
		btnDeleteAnnouncementButton = new JButton("Delete");
		btnDeleteAnnouncementButton.setBounds(429, 207, 105, 23);
		contentPane.add(btnDeleteAnnouncementButton);
		btnDeleteAnnouncementButton.addActionListener(action);
		btnDeleteAnnouncementButton.setVisible(false);
		
		btnCancelButton = new JButton("Cancel");
		btnCancelButton.setBounds(132, 207, 89, 23);
		contentPane.add(btnCancelButton);
		btnCancelButton.addActionListener(action);
		btnCancelButton.setVisible(false);
		
		btnClearButton = new JButton("Clear");
		btnClearButton.setBounds(411, 207, 103, 23);
		contentPane.add(btnClearButton);
		btnClearButton.addActionListener(action);
		
		try {
			MyDbConnection connect = new MyDbConnection();
			Connection con = connect.getConnection();
			Statement stmt=con.createStatement();
			String txt="";
			txt = "select announcement_id,announcement_desc from announcements";
			ResultSet rs = stmt.executeQuery(txt);
			DefaultTableModel tableModel = new DefaultTableModel() ;
			table_1 = new JTable(tableModel);
			tableModel.addColumn("Announcement Id");
			tableModel.addColumn("Announcement Description");
			int i=0;
			while(rs.next()) {
				tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2) });
				System.out.println(rs.getString(2));
				i++;
			}
			table_1.setVisible(true);
			js.setBounds(20,290,640,150);	
			getContentPane().add(js);
			js.setViewportView(table_1);
			
			ListSelectionModel model = table_1.getSelectionModel();
			model.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if(!model.isSelectionEmpty()) {
						int selectedRow = model.getMinSelectionIndex();
						btnAddAnnouncementButton.setVisible(false);
						btnUpdateAnnouncementButton.setVisible(true);
						btnDeleteAnnouncementButton.setVisible(true);
						btnCancelButton.setVisible(true);
						btnClearButton.setVisible(false);

						//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
						try {
							String txt = "select announcement_id,announcement_desc,Announcement_start_date,Announcement_end_date from announcements where announcement_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
							ResultSet rs = stmt.executeQuery(txt);
							while(rs.next()) {
								textFieldAnnouncementId.setText(Integer.toString(rs.getInt(1)));
								textFieldAnnouncementDescription.setText(rs.getString(2));
								startDate.setDateTimeStrict(rs.getTimestamp(3).toLocalDateTime());
								endDate.setDateTimeStrict(rs.getTimestamp(4).toLocalDateTime());
							}
						}
						catch(Exception exe) {
							exe.printStackTrace();
						}
					}
				}
			});
			
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
	}
	
	void clearText() {
		textFieldAnnouncementId.setText("");
		textFieldAnnouncementDescription.setText("");
		startDate.setDateTimeStrict(null);
		endDate.setDateTimeStrict(null);
	}
	

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				 
				
				if(e.getSource()==btnAddAnnouncementButton) {
					
					txt = "insert into announcements(Announcement_id,Announcement_desc,Announcement_start_date,Announcement_end_date) values('"+textFieldAnnouncementId.getText()+"','"+textFieldAnnouncementDescription.getText()+"',to_date('"+startDate.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),to_date('"+endDate.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'))";
					System.out.println(txt);
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Announcement");
					clearText(); 
				}
				else if(e.getSource()==btnDeleteAnnouncementButton) {
					txt = "delete from announcements where Announcement_desc='"+textFieldAnnouncementDescription.getText()+"' ";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Announcement Deleted");
					clearText(); 
				}
				
				else if(e.getSource()==btnUpdateAnnouncementButton) {
					txt = "update announcements set Announcement_id ='"+Integer.parseInt(textFieldAnnouncementId.getText())+"', Announcement_desc='"+textFieldAnnouncementDescription.getText()+"',Announcement_start_date= to_date('"+startDate.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi'),Announcement_end_date = to_date('"+endDate.getDateTimeStrict().format(DateTimeFormatter.ofPattern("dd-MMM-yy HH:mm"))+"','dd-mon-yy hh24:mi') where Announcement_id='"+textFieldAnnouncementId.getText()+"' ";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Announcement Updated");
					clearText(); 
				}
				
				else if(e.getSource()==btnCancelButton) {
					btnAddAnnouncementButton.setVisible(true);
					btnUpdateAnnouncementButton.setVisible(false);
					btnDeleteAnnouncementButton.setVisible(false);
					btnCancelButton.setVisible(false);
					clearText(); 
					btnClearButton.setVisible(true);
				}
				
				else if(e.getSource()==btnClearButton) {
					clearText(); 
				}
				
				txt = "select announcement_id,announcement_desc from announcements";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("Announcement Id");
				tableModel.addColumn("Announcement Description");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(20,290,640,150);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							btnAddAnnouncementButton.setVisible(false);
							btnUpdateAnnouncementButton.setVisible(true);
							btnDeleteAnnouncementButton.setVisible(true);
							btnCancelButton.setVisible(true);
							btnClearButton.setVisible(false);
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select announcement_id,announcement_desc,Announcement_start_date,Announcement_end_date from announcements where announcement_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldAnnouncementId.setText(Integer.toString(rs.getInt(1)));
									textFieldAnnouncementDescription.setText(rs.getString(2));
									startDate.setDateTimeStrict(rs.getTimestamp(3).toLocalDateTime());
									endDate.setDateTimeStrict(rs.getTimestamp(4).toLocalDateTime());
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
								JOptionPane.showMessageDialog(null,"Table error");
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
				JOptionPane.showMessageDialog(null,"Invalid Input. Please try again");
			}
			
		}
	}
}
