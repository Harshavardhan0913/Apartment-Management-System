package ams;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

import ams.Charges.SwingAction;

public class Charges1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Charges1 frame = new Charges1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField textFieldChargesId;
	private JTextField textFieldChargesType;
	private JTextField textFieldChargesDescription;
	private JTextField textFieldChargesAmount;
	private final Action action = new SwingAction();
	private JMenu mnUsersMenu;
	private JMenu mnAnnouncementsMenu;
	private JMenu mnVisitorsMenu;
	private JMenu mnFlatsMenu;
	private JMenu mnchargesMenu;
	private JMenuItem mntmAddChargesMenuItem;
	private JMenuItem mntmEditChargesMenuItem;
	private JMenuItem mntmDeleteChargesMenuItem;
	private JButton btnAddChargesButton;
	private JButton btnUpdateChargesButton;
	private JButton btnDeleteChargesButton;
	private JTable table_1;
	private JScrollPane js = new JScrollPane(table_1);
	private JMenu mnExpensesMenu;
	private JLabel lblNewLabel_4;
	private JTextField textFieldFlatNo;
	public Charges1() {
		setTitle("Apartment Management System - Charges");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		if(login.userName.isEmpty()) {
			dispose();
		}
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 679, 22);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu_3 = new JMenu("Home");
		mnNewMenu_3.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				home h = new home();
				h.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_3);
		
		mnUsersMenu = new JMenu("Users");
		mnUsersMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Users u = new Users();
				u.setVisible(true);
			}
		});
		menuBar.add(mnUsersMenu);
		
		mnAnnouncementsMenu = new JMenu("Announcements");
		mnAnnouncementsMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Announcements a = new Announcements();
				a.setVisible(true);
			}
		});
		
		menuBar.add(mnAnnouncementsMenu);
		
		mnVisitorsMenu = new JMenu("Visitors");
		mnVisitorsMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Visitors v = new Visitors();
				v.setVisible(true);
			}
		});
		
		menuBar.add(mnVisitorsMenu);
		
		mnFlatsMenu = new JMenu("Flats");
		mnFlatsMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Flats f = new Flats();
				f.setVisible(true);
			}
		});
		menuBar.add(mnFlatsMenu);
		
		mnExpensesMenu = new JMenu("Expenses");
		mnExpensesMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Expenses exp = new Expenses();
				exp.setVisible(true);
			}
		});
		menuBar.add(mnExpensesMenu);
		
		mnchargesMenu = new JMenu("Charges");
		menuBar.add(mnchargesMenu);
		
		mntmAddChargesMenuItem = new JMenuItem("Add charges");
		mnchargesMenu.add(mntmAddChargesMenuItem);
		mntmAddChargesMenuItem.addActionListener(action);
		
		mntmEditChargesMenuItem = new JMenuItem("Edit charges");
		mnchargesMenu.add(mntmEditChargesMenuItem);
		mntmEditChargesMenuItem.addActionListener(action);
		
		mntmDeleteChargesMenuItem = new JMenuItem("Delete charges");
		mnchargesMenu.add(mntmDeleteChargesMenuItem);
		mntmDeleteChargesMenuItem.addActionListener(action);
		
		lblNewLabel = new JLabel("Charge Id");
		lblNewLabel.setBounds(159, 100, 114, 14);
		contentPane.add(lblNewLabel);
		lblNewLabel.setVisible(false);
		
		lblNewLabel_1 = new JLabel("Charge Type");
		lblNewLabel_1.setBounds(159, 125, 114, 14);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setVisible(false);
		
		lblNewLabel_2 = new JLabel("Charge description");
		lblNewLabel_2.setBounds(159, 150, 114, 14);
		contentPane.add(lblNewLabel_2);
		lblNewLabel_2.setVisible(false);
		
		lblNewLabel_3 = new JLabel("Charge Amount");
		lblNewLabel_3.setBounds(159, 175, 114, 14);
		contentPane.add(lblNewLabel_3);
		lblNewLabel_3.setVisible(false);
		
		textFieldChargesId = new JTextField();
		textFieldChargesId.setBounds(283, 97, 96, 20);
		contentPane.add(textFieldChargesId);
		textFieldChargesId.setColumns(10);
		textFieldChargesId.setVisible(false);
		
		textFieldChargesType = new JTextField();
		textFieldChargesType.setBounds(283, 122, 96, 20);
		contentPane.add(textFieldChargesType);
		textFieldChargesType.setColumns(10);
		textFieldChargesType.setVisible(false);
		
		textFieldChargesDescription = new JTextField();
		textFieldChargesDescription.setBounds(283, 147, 96, 20);
		contentPane.add(textFieldChargesDescription);
		textFieldChargesDescription.setColumns(10);
		textFieldChargesDescription.setVisible(false);
		
		textFieldChargesAmount = new JTextField();
		textFieldChargesAmount.setBounds(283, 172, 96, 20);
		contentPane.add(textFieldChargesAmount);
		textFieldChargesAmount.setColumns(10);
		textFieldChargesAmount.setVisible(false);
		
		btnAddChargesButton = new JButton("Add");
		btnAddChargesButton.setBounds(224, 231, 89, 23);
		contentPane.add(btnAddChargesButton);
		btnAddChargesButton.setVisible(false);
		btnAddChargesButton.addActionListener(action);
		
		btnUpdateChargesButton = new JButton("Update");
		btnUpdateChargesButton.setBounds(224, 231, 101, 23);
		contentPane.add(btnUpdateChargesButton);
		btnUpdateChargesButton.setVisible(false);
		btnUpdateChargesButton.addActionListener(action);
		
		btnDeleteChargesButton = new JButton("Delete");
		btnDeleteChargesButton.setBounds(224, 231, 114, 23);
		contentPane.add(btnDeleteChargesButton);
		btnDeleteChargesButton.setVisible(false);
		btnDeleteChargesButton.addActionListener(action);
		
		lblNewLabel_4 = new JLabel("Flat Number");
		lblNewLabel_4.setBounds(159, 200, 48, 14);
		contentPane.add(lblNewLabel_4);
		lblNewLabel_4.setVisible(false);
		
		textFieldFlatNo = new JTextField();
		textFieldFlatNo.setBounds(283, 197, 96, 20);
		contentPane.add(textFieldFlatNo);
		textFieldFlatNo.setColumns(10);
		textFieldFlatNo.addActionListener(action);
		textFieldFlatNo.setVisible(false);
		JMenu mnNewMenu_2 = new JMenu("Payments");
		mnNewMenu_2.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Payments p = new Payments();
				p.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_2);
		JMenu mnNewMenu = new JMenu("Residents");
		mnNewMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Residents r = new Residents();
				r.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_4 = new JMenu("Committee");
		mnNewMenu_4.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				dispose();
				Committee c = new Committee();
				c.setVisible(true);
			}
		});
		menuBar.add(mnNewMenu_4);
	}
	

	public class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==mntmAddChargesMenuItem) {
				btnAddChargesButton.setVisible(true);
				btnUpdateChargesButton.setVisible(false);
				btnDeleteChargesButton.setVisible(false);
				textFieldChargesId.setVisible(true);
				textFieldChargesType.setVisible(true);
				textFieldChargesDescription.setVisible(true);
				textFieldChargesAmount.setVisible(true);
				textFieldFlatNo.setVisible(true);
				lblNewLabel.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2.setVisible(true);
				lblNewLabel_3.setVisible(true);
				lblNewLabel_4.setVisible(true);
			}
			else if(e.getSource()==mntmEditChargesMenuItem) {
				btnAddChargesButton.setVisible(false);
				btnUpdateChargesButton.setVisible(true);
				btnDeleteChargesButton.setVisible(false);
				textFieldChargesId.setVisible(true);
				textFieldChargesType.setVisible(true);
				textFieldChargesDescription.setVisible(true);
				textFieldChargesAmount.setVisible(true);
				textFieldFlatNo.setVisible(true);
				lblNewLabel.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2.setVisible(true);
				lblNewLabel_3.setVisible(true);
				lblNewLabel_4.setVisible(true);
			}
			else if(e.getSource()==mntmDeleteChargesMenuItem) {
				btnAddChargesButton.setVisible(false);
				btnUpdateChargesButton.setVisible(false);
				btnDeleteChargesButton.setVisible(true);
				textFieldChargesId.setVisible(true);
				textFieldChargesType.setVisible(true);
				textFieldChargesDescription.setVisible(true);
				textFieldChargesAmount.setVisible(true);
				textFieldFlatNo.setVisible(true);
				lblNewLabel.setVisible(true);
				lblNewLabel_1.setVisible(true);
				lblNewLabel_2.setVisible(true);
				lblNewLabel_3.setVisible(true);
				lblNewLabel_4.setVisible(true);
			}
			try {
				MyDbConnection connect = new MyDbConnection();
				Connection con = connect.getConnection();
				Statement stmt=con.createStatement();
				String txt="";
				
				
				if(e.getSource()==btnAddChargesButton) {
					
					txt = "insert into charges values('"+textFieldChargesId.getText()+"','"+textFieldFlatNo.getText()+"','"+textFieldChargesType.getText()+"','"+textFieldChargesDescription.getText()+"','"+textFieldChargesAmount.getText()+"')";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Added Charges");
					 
				}
				else if(e.getSource()==btnDeleteChargesButton) {
					txt = "delete from charges where charges_id ='"+textFieldChargesId.getText()+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Charges Deleted");
				}
				
				else if(e.getSource()==btnUpdateChargesButton) {
					txt = "update charges set charges_id ='"+Integer.parseInt(textFieldChargesId.getText())+"',flat_no = '"+textFieldFlatNo.getText()+"',charges_amount='"+Integer.parseInt(textFieldChargesAmount.getText())+"',charges_type = '"+textFieldChargesType.getText()+"',charges_desc = '"+textFieldChargesDescription.getText()+"' where charges_id='"+Integer.parseInt(textFieldChargesId.getText())+"'";
					stmt.executeQuery(txt);
					JOptionPane.showMessageDialog(null,"Charges Updated");
				}
				
				txt = "select charges_id,charges_desc,charges_amount,flat_no from charges";
				ResultSet rs = stmt.executeQuery(txt);
				DefaultTableModel tableModel = new DefaultTableModel() ;
				table_1 = new JTable(tableModel);
				tableModel.addColumn("charges Id");
				tableModel.addColumn("charges Description");
				tableModel.addColumn("charges Amount");
				tableModel.addColumn("Flat Number");
				int i=0;
				while(rs.next()) {
					tableModel.insertRow(i,new Object[] { rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4) });
					System.out.println(rs.getString(2));
					i++;
				}
				table_1.setVisible(true);
				js.setBounds(0,290,640,400);	
				getContentPane().add(js);
				js.setViewportView(table_1);
				
				ListSelectionModel model = table_1.getSelectionModel();
				model.addListSelectionListener(new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if(!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							//JOptionPane.showMessageDialog(null,"Selected Row "+table_1.getModel().getValueAt(selectedRow,1));
							try {
								String txt = "select charges_id,charges_amount,charges_type,charges_desc,flat_no from charges where charges_id = '"+table_1.getModel().getValueAt(selectedRow,0)+"'";
								ResultSet rs = stmt.executeQuery(txt);
								while(rs.next()) {
									textFieldChargesId.setText(rs.getString(1));
									textFieldChargesAmount.setText(rs.getString(2));
									textFieldChargesType.setText(rs.getString(3));
									textFieldChargesDescription.setText(rs.getString(4));
									textFieldFlatNo.setText(rs.getString(5));
								}
							}
							catch(Exception exe) {
								exe.printStackTrace();
							}
						}
					}
				});
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}