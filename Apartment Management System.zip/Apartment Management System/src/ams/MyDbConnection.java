package ams;
import java.sql.*;
public class MyDbConnection {
	public Connection getConnection() {
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","admin","Admin@123"); 	
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection( "jdbc:oracle:thin:@localhost:1521:xe","Harsha","vasavi");
			return conn;
		}
		catch(Exception e) {
			System.out.println(e);

		}
		return null; 
	}
}
